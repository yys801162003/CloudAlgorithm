# shapeLaserInspector · Qt 5.14.2

## 在 Qt Creator 中构建

1. 在 Windows 上安装 Qt Creator、Qt **5.14.2 MSVC 2017 64-bit** 和 Qt Network Authorization 模块。安装 Visual Studio 2019 的 **使用 C++ 的桌面开发**工作负载，包含 MSVC v142 x64 工具和 Windows SDK。
2. 在 Qt Creator 中打开根目录的 `shapeLaserInspector.pro`。为 Kit 选择 Qt 5.14.2 的 `msvc2017_64/bin/qmake.exe` 和 MSVC 2019 x64 编译器。Qt 5.14.2 的 MSVC 2017 x64 库可以由 MSVC 2019 x64 链接。
3. 选择 Debug 或 Release，保留 Qt Creator 默认的独立构建目录，然后构建根项目。主程序和本项目的 DLL 输出到构建目录中的 `bin/x64/Debug` 或 `bin/x64/Release`。运行目标为 `shapeLaserInspectorApplication.exe`。

根工程会先构建 `shapeLaserInspector` 和 `ShapeAlgorithm`，再链接主程序。与原工程一致，核心库在 Debug 为静态库，在 Release 为 DLL。算法库在两种配置下均为 DLL。第三方头文件和相应配置的 x64 导入库由 `jni/dep` 提供。

## 运行依赖

- 将对应 Debug 或 Release 的 aistring DLL、GoSDK 的 `GoSdk.dll` 和 `kApi.dll` 及其传递依赖放到 EXE 目录，或让运行环境通过 `PATH` 找到它们。请从原设备部署目录或供应商 SDK 获取这些文件。
- OpenCV 导入库要求 Debug 使用 `opencv_world460d.dll`，Release 使用 `opencv_world460.dll`。
- 如需在 Qt Creator 外运行，使用同一个 Qt 5.14.2 Kit 的 `windeployqt.exe --release 路径\shapeLaserInspectorApplication.exe` 部署 Qt DLL 和插件。部署 Debug 时使用 `--debug`。第三方 DLL 仍需另行提供。
- 构建会复制 `environment.json` 到 EXE 目录。OpenGL 着色器和坐标图已编入 Qt 资源。原业务代码中的设备配置和 `D:\shapeLaser` 等路径仍需匹配现场环境。

## 验证范围

当前迁移在 Linux 工作区进行。已用 Qt 5.14.2 的 qmake 检查 Debug 和 Release 的 Windows 构建规则生成，并用同版本的 `uic`、`moc`、`rcc` 验证了界面、元对象和资源生成。Windows MSVC 编译、链接、启动以及相机和 PLC 联调需在具有上述 SDK 和硬件的 Windows 环境中验证。
