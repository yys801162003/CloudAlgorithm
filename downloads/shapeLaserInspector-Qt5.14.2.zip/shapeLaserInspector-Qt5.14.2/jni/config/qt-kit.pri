!equals(QT_VERSION, 5.14.2): error("Select the Qt 5.14.2 kit.")
!win32-msvc*: error("The bundled SDK libraries require Windows MSVC.")
!equals(QT_ARCH, x86_64): error("Select the 64-bit Qt kit.")
