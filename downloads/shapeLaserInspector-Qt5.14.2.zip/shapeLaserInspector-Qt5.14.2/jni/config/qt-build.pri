include(qt-kit.pri)

CONFIG += c++17
CONFIG -= debug_and_release debug_and_release_target
QMAKE_CXXFLAGS += /utf-8

CONFIG(debug, debug|release) {
    BUILD_VARIANT = Debug
} else {
    BUILD_VARIANT = Release
}

JNI_DIR = $$clean_path($$PWD/..)
AIS_DIR = $$JNI_DIR/dep/aistring
OPENCV_DIR = $$JNI_DIR/dep/opencv
GOSDK_DIR = $$JNI_DIR/dep/GoSdk

INCLUDEPATH += \
    "$$JNI_DIR/include" \
    "$$AIS_DIR/include" \
    "$$AIS_DIR/include/AsBasic" \
    "$$AIS_DIR/include/AsAlgorithm" \
    "$$AIS_DIR/include/AsQBasic" \
    "$$AIS_DIR/include/AsCore" \
    "$$AIS_DIR/include/AsGraphics" \
    "$$AIS_DIR/include/AsDevelopFramework" \
    "$$OPENCV_DIR/include" \
    "$$OPENCV_DIR/include/opencv2"

LIBS += \
    -L"$$AIS_DIR/lib/x64/$$BUILD_VARIANT" \
    -L"$$OPENCV_DIR/lib/x64/$$BUILD_VARIANT" \
    -lAsBasic -lAsAlgorithm -lAsQBasic -lAsCore -lAsDevelopFramework -lopencv_world

# All three .pro files sit three levels below the root project.
DESTDIR = $$clean_path($$OUT_PWD/../../../bin/x64/$$BUILD_VARIANT)
OBJECTS_DIR = $$BUILD_VARIANT/obj
MOC_DIR = $$BUILD_VARIANT/moc
UI_DIR = $$BUILD_VARIANT/ui
RCC_DIR = $$BUILD_VARIANT/rcc
