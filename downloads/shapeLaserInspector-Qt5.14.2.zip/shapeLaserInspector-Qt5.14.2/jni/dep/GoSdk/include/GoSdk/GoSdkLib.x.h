/**
 * @file    GoSdkLib.x.h
 *
 * @internal
 * Copyright (C) 2016-2022 by LMI Technologies Inc.
 * Licensed under the MIT License.
 * Redistributed files must retain the above copyright notice.
 */
#ifndef GO_SDK_LIB_X_H
#define GO_SDK_LIB_X_H

#define GO_SDK_VERSION_MAJOR 6
#define GO_SDK_VERSION_MINOR 1
#define GO_SDK_VERSION_RELEASE 40
#define GO_SDK_VERSION_BUILD 7


kDeclareAssemblyEx(Go, GoSdk)

#endif
