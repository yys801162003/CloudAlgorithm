﻿#pragma once
#include "AsCvDefine.h"


namespace AsCv {

	/**
	 * @desc Ransc拟合
	 * @param:
	 *	-vPoint:传入点集
	 *	-line:拟合结果
	 *	-maxDis:点到拟合结果的最大距离，超过这个值，认定点不在直线上
	 *	-breakNumRatio:跳出数量比例，拟合结果超过这个比例时，认定拟合结果非常好，直接跳出
	 *	-minNumRatio:最小数量比例，最终结果低于这个比例的时候认定拟合失败
	 */
	AS_ALGORITHM_EXPORT int ranscFitLine(const std::vector<cv::Point2i>& vPoint, Line& line, double maxDis, double breekNumRatio, double minNumRatio);

	/**
	 * @desc Ransc拟合
	 * @param:
	 *	-vPoint:传入点集
	 *	-line:拟合结果
	 *	-maxDis:点到拟合结果的最大距离，超过这个值，认定点不在直线上
	 *	-breakNumRatio:跳出数量比例，拟合结果超过这个比例时，认定拟合结果非常好，直接跳出
	 *	-minNumRatio:最小数量比例，最终结果低于这个比例的时候认定拟合失败
	 */
	AS_ALGORITHM_EXPORT int ranscFitLine(const std::vector<cv::Point2d>& vPoint, Line& line, double maxDis, double breekNumRatio, double minNumRatio);

	/**
	 * @desc OpenCV直接拟合直线
	 */
	AS_ALGORITHM_EXPORT int cvFitLine(const std::vector<cv::Point2i>& vPoint, Line& line);


	/**
	* @desc OpenCV直接拟合直线
	*/
	AS_ALGORITHM_EXPORT int cvFitLine(const std::vector<cv::Point2d>& vPoint, Line& line);

	/**
	 * @desc 拟合圆 
	 */
	AS_ALGORITHM_EXPORT int fitCircle(const std::vector<cv::Point2i>& vPoint, Circle& circle);

	/**
	 * @desc 拟合圆 
	 */
	AS_ALGORITHM_EXPORT int ranscFitCircle(const std::vector<cv::Point2i>& vPoint,Circle& circle, double maxDis, double breekNumRatio, double minNumRatio);

	/**
	 * @desc 拟合平面 TODO
	 */
	AS_ALGORITHM_EXPORT int fitPlane(const std::vector<cv::Point3d>& vPoint, Face& face);


};
