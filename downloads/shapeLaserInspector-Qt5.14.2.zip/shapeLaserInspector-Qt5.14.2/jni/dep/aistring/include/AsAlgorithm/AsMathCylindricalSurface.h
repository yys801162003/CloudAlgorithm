﻿#pragma once
#include "AsMathBasic.h"

class AS_MATH_API AsMathCylindricalSurface {
public:
	AsMathCylindricalSurface(const AsMathLine3D& center_axis, double radius);

public:
	AsMathLine3D center_axis;
	double radius;

public:
	double calcDistance(const AsMathPoint3D& p) const;

};