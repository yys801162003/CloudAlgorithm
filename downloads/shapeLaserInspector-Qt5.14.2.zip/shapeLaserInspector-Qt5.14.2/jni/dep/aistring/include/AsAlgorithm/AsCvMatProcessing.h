﻿#pragma once
#include "AsCvDefine.h"

namespace AsCv {

	/**
	 * @desc 在图像中提取边缘的点,用于只存在前景和背景的图
	 */
	AS_ALGORITHM_EXPORT int extractLinePoints(const cv::Mat& mat, std::vector<cv::Point2i>& vPoint, int grayThreshold);

	/**
	 * @desc 在二值化图像中提取所有白色点的坐标
	 */
	AS_ALGORITHM_EXPORT std::vector<cv::Point2i> getAllWhitePoint(const cv::Mat& mat);

	/**
	 * @desc:根据给定的灰度图，找到黑色部分的角点
	 * @author:sunke 2023/1/30
	 * @modify:sunke 2023/1/30
	 * @params:
		mat-输入参数，只有一个角的灰度图；
		cornerPoint-输出参数，角点坐标；
	 * @ret:0-成功,其他-失败
	 */
	AS_ALGORITHM_EXPORT int findCornerPoint(const cv::Mat& mat, cv::Point& cornerPoint);

	/**
	 * @desc:根据给定的灰度图，找到黑色部分的角点、角的水平边缘点集和角的垂直边缘点集
	 * @author:sunke 2023/1/30
	 * @modify:sunke 2023/1/30
	 * @params:
	 *	mat-输入参数，只有一个角,角的边缘斜率不超过20°的灰度图；
	 *	cornerPoint-输出参数，角点坐标；
	 *	xEdge-输出参数，角的水平边缘点集；
	 *	yEdge-输出参数，角的垂直边缘点集；
	 *	binaThre-二值化阈值，默认为170；
	 * @ret:0-成功,其他-失败
	 */
	AS_ALGORITHM_EXPORT int findCornerPointAndEdgePoints(const cv::Mat& mat, cv::Point& cornerPoint, std::vector<cv::Point2i>& xEdgePoints, std::vector<cv::Point2i>& yEdgePoints, int binaThre=170);

	/**
	 * @desc:根据角点坐标找x方向的点
	 * @author:sunke 2023/1/30
	 * @modify:sunke 2023/2/1
	 * @params:
	 *	mat-输入参数，只有一个角,角的边缘斜率不超过20°的二值图；
	 *	cornerPoint-输入参数，角点坐标；
	 *	xEdge-输出参数，角的水平边缘点集；
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void getXEdge(const cv::Mat& mat, const cv::Point& corner, std::vector<cv::Point>& xEdge);

	/**
	 * @desc:根据角点坐标找x方向的点
	 * @author:sunke 2023/1/30
	 * @modify:sunke 2023/2/1
	 * @params:
	 *	mat-输入参数，只有一个角,角的边缘斜率不超过20°的二值图；
	 *	cornerPoint-输入参数，角点坐标；
	 *	yEdge-输出参数，角的竖直边缘点集；
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void getYEdge(const cv::Mat& mat, const cv::Point& corner, std::vector<cv::Point>& yEdge);

	/**
	 * @desc:根据给定的灰度图，找到顶部边缘点集
	 * @author:sunke 2023/2/7
	 * @modify:sunke 2023/2/7
	 * @params:
		mat-输入参数，顶部边缘矩形框截图的灰度图；
		topPoints-输出参数，顶部边缘点集
		binaThre-二值化阈值，默认为180
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void findTopPoints(const cv::Mat& mat, std::vector<cv::Point2i>& topPoints, int binaThre = 180);

	/**
	 * @desc:根据给定的灰度图，找到底部边缘点集
	 * @author:sunke 2023/2/7
	 * @modify:sunke 2023/2/7
	 * @params:
		mat-输入参数，底部边缘矩形框截图的灰度图；
		topPoints-输出参数，底部边缘点集
		binaThre-二值化阈值，默认为180
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void findBottomPoints(const cv::Mat& mat, std::vector<cv::Point2i>& bottomPoints, int binaThre = 180);

	/**
	 * @desc:根据给定的灰度图，找到左部边缘点集
	 * @author:sunke 2023/2/7
	 * @modify:sunke 2023/2/7
	 * @params:
		mat-输入参数，左部边缘矩形框截图的灰度图；
		topPoints-输出参数，左部边缘点集
		binaThre-二值化阈值，默认为180
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void findLeftPoints(const cv::Mat& mat, std::vector<cv::Point2i>& leftPoints, int binaThre = 180);

	/**
	 * @desc:根据给定的灰度图，找到右部边缘点集
	 * @author:sunke 2023/2/7
	 * @modify:sunke 2023/2/7
	 * @params:
		mat-输入参数，右部边缘矩形框截图的灰度图；
		rightPoints-输出参数，右部边缘点集
		binaThre-二值化阈值，默认为180
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void findRightPoints(const cv::Mat& mat, std::vector<cv::Point2i>& rightPoints, int binaThre = 180);
	   

	/**
	 * @desc:图像量化
	 * @author:wj 2023/6/8
	 * @modify:wj 2023/6/8
	 * @params:
		input-输入参数，输入灰度图；
		output-输出参数，量化后的灰度图
		level-量化等级
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void quantifyImage(const cv::Mat& input, cv::Mat& output, int level);


	/**
	 * @desc:细化图像
	 * @author:wj 2023/6/8
	 * @modify:wj 2023/6/8
	 * @params:
		src-源输入图像，灰度图；
		maxIterations-最大迭代次数，影响最终细化效果，默认-1，细化到宽度为1
	 * @ret Mat-细化后的灰度图
	 */
	AS_ALGORITHM_EXPORT cv::Mat thinImage(const cv::Mat & src, const int maxIterations = -1);


	/**
	 * @desc:直角坐标转极坐标
	 * @author:王杰 2023/8/24
	 * @modify:王杰 2023/8/24
	 * @params:
		input-源输入图像，灰度图；
		output-输出图像，极坐标图；
		center-展开中心；
		radius-展开半径；
	 * @ret int-错误码，0为无错误
	 */
	AS_ALGORITHM_EXPORT int cart2polImg(const cv::Mat& input, cv::Mat& output, const cv::Point2f& center, const int& radius);

	/**
	 * @desc:极坐标转直角坐标
	 * @author:王杰 2023/8/24
	 * @modify:王杰 2023/8/24
	 * @params:
		input-源输入图像，灰度图；
		output-输出图像，极坐标图；
		center-展开中心；
		radius-展开半径；
	 * @ret int-错误码，0为无错误
	 */
	AS_ALGORITHM_EXPORT int pol2cartImg(const cv::Mat& input, cv::Mat& output, const cv::Point2f& center, const int& radius);

};

