#pragma once
#include "AsAlgorithmGlobal.h"
#include "AsContainer.h"
#include "AsObject.h"

__AS_JY(Update 2023.5.24)
class AS_ALGORITHM_EXPORT AsAlgorithmParameter {
public:
	AsAlgorithmParameter();
	AsAlgorithmParameter(int functionOption);

private:
	int mFunctionOption;
	AsContainer mParams;

public:
	AsContainer& conta();

public:
	int			getFunctionOption();
	AsObject&	getObject(const std::string& name);
	AsVariant&	getVariant(const std::string& name);
	const AsObject& getConstObject(const std::string& name);
	const AsVariant& getConstVariant(const std::string& name);

	void setFunctionOption(int functionOption);
	void setObject(const std::string& name, const AsObject& object);
	void setVariant(const std::string& name, const AsVariant& variant);
	void setConstObject(const std::string& name, const AsObject& object);
	void setConstVariant(const std::string& name, const AsVariant& variant);

};

