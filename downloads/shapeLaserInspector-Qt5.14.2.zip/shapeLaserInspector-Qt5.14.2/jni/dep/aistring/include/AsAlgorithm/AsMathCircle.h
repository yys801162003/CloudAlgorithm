﻿#pragma once
#include "AsMathBasic.h"

class AS_MATH_API AsMathCircle {
public:
	AsMathCircle();
	AsMathCircle(double cx, double cy, double r);
	AsMathCircle(const cv::Point2f& p1, const cv::Point2f& p2, const cv::Point2f& p3);

public:
	static AsMathCircle fromVec3f(const cv::Vec3f& vec3f);

public:
	double cx;
	double cy;
	double r;

public:
	double getCenterX() const;
	double getCenterY() const;
	double getRadius() const;
	double getDiameter() const;
	cv::Point getCenter() const;
	cv::Point2f getCenterF() const;
	double getArea() const;
	double getPerimeter() const;

public:
	double calcDistance(const cv::Point2i& p) const;
	double calcDistance(const cv::Point2f& p) const;
	double calcY(double x) const;
	double calcX(double y) const;

	std::vector<cv::Point> calcIntersect(cv::Point p1, cv::Point p2) const;

public:
	std::string tostr() const;

};
