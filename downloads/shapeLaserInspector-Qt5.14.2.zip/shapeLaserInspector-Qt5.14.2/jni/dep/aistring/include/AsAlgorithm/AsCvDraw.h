﻿#pragma once
#include "AsCvDefine.h"


namespace AsCv {

	/**
	 * @desc 在图像上画线
	 */
	AS_ALGORITHM_EXPORT void drawLine(cv::Mat& mat, const Line& line);

	/**
	 * @desc 在图像上画2d点(点本身是图像上的点)
	 */
	AS_ALGORITHM_EXPORT void drawPoints(cv::Mat& mat, const std::vector<cv::Point2i>& vPoint,cv::Scalar color=cv::Scalar(0, 255, 0));


	/**
	 * @desc 在一个合适的范围内画3d点集
	 */
	AS_ALGORITHM_EXPORT cv::Mat drawPointsAsMat(const std::vector<cv::Point2d>& vPoint);

	/**
	 * @desc 在一个合适的范围内画3d点集
	 */
	AS_ALGORITHM_EXPORT void drawPointsOnMat(cv::Mat& mat, const std::vector<cv::Point2d>& vPoint, cv::Scalar color = cv::Scalar(0, 255, 0));


	/**
	 * @desc 在一个适指定的映射范围内画3d点集
	 */
	AS_ALGORITHM_EXPORT void drawLineStripOnMat(cv::Mat& mat, const std::vector<cv::Point2d>& vPoint, double minX, double maxX, double minY, double maxY, cv::Scalar color = cv::Scalar(0, 255, 0));


	/**
	 * @desc 在一个合适的范围内画3d点集
	 */
	AS_ALGORITHM_EXPORT void drawPointsOnMat(cv::Mat& mat, const std::vector<cv::Point2d>& vPoint, double minX, double maxX, double minY, double maxY, cv::Scalar color = cv::Scalar(0, 255, 0));


	/**
	 * @desc 画等高线
	 * @param
	 *	-input:输入图像，必须时CV_32FC1的类型
	 *	-output输出图像
	 *	-decimal:等高线分度，为0时自动计算
	 */
	AS_ALGORITHM_EXPORT void drawContourLine(const cv::Mat& input, cv::Mat& output, double decimal = 0);


	AS_ALGORITHM_EXPORT void drawRotateRectOnMat(cv::Mat& mat, const cv::RotatedRect& rect, cv::Scalar color = cv::Scalar(0, 255, 0));


	/**
	 * @desc:按灰阶绘制图像直方图
	 * @author:wj 2023/6/1
	 * @modify:wj 2023/6/1
	 * @params:
		mat-输入参数，灰度图；
		resultMat-输出Mat(1920*1080*3)
		histSize-直方图级别，默认为256
	 * @ret void
	 */
	AS_ALGORITHM_EXPORT void drawHistGraph(cv::Mat mat, cv::Mat& resultMat,int histSize = 256);
};
