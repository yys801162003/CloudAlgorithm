﻿#pragma once
#include "AsMathBasic.h"
#include "AsMathLine.h"
#include "AsMathRect.h"
#include "AsMathCircle.h"
#include <opencv2\imgproc.hpp>

class AS_MATH_API AsMathColor {
public:
	static const cv::Scalar black;
	static const cv::Scalar white;
	static const cv::Scalar gray;

	static const cv::Scalar red;
	static const cv::Scalar orange;
	static const cv::Scalar yellow;
	static const cv::Scalar olivine;
	static const cv::Scalar green;
	static const cv::Scalar darkGreen;
	static const cv::Scalar cyan;
	static const cv::Scalar indigo;
	static const cv::Scalar blue;
	static const cv::Scalar purple;
	static const cv::Scalar magenta;
	static const cv::Scalar wine;
	
public:
	static cv::Scalar _default;					// red

public:
	static cv::Vec3b toVec3b(int color);
	static cv::Vec4b toVec4b(int color);

};

namespace AsMath {

	cv::Scalar AS_MATH_API rgb(int r, int g, int b);

	void AS_MATH_API drawPoint(cv::Mat& mat, const cv::Point& point, const cv::Scalar& color = AsMathColor::_default, int radius = 0);

	void AS_MATH_API drawPoints(cv::Mat& mat, const std::vector<cv::Point>& points, const cv::Scalar& color = AsMathColor::_default, int radius = 0);

	void AS_MATH_API drawPoints(cv::Mat& mat, const std::vector<std::vector<cv::Point>>& points, const cv::Scalar& color = AsMathColor::_default, int radius = 0);

	void AS_MATH_API drawContour(cv::Mat& mat, const std::vector<cv::Point>& contour, const cv::Scalar& color = AsMathColor::_default, int thickness = 1, int lineType = cv::LINE_8);

	void AS_MATH_API drawRect(cv::Mat& mat, const cv::Rect& rect, const cv::Scalar& color = AsMathColor::_default, int thickness = 1, int lineType = cv::LINE_8, int shift = 0);

	void AS_MATH_API drawRect(cv::Mat& mat, const AsMathRect& rect, const cv::Scalar& color = AsMathColor::_default, int thickness = 1, int lineType = cv::LINE_8, int shift = 0);

	void AS_MATH_API drawRotatedRect(cv::Mat& mat, const cv::RotatedRect& rotatedRect, const cv::Scalar& color = AsMathColor::_default, int thickness = 1, int lineType = cv::LINE_8, int shift = 0);

	void AS_MATH_API drawText(cv::Mat& mat, std::string text, cv::Point position, const cv::Scalar& color = AsMathColor::_default, int fontFace = cv::FONT_HERSHEY_PLAIN, double fontScale = 1.0, int thickness = 1, int lineType = cv::LINE_8, bool bottomLeftOrigin = false);

	void AS_MATH_API drawLine(cv::Mat& mat, const AsMathLine& line, const cv::Scalar& color = AsMathColor::_default, int thickness = 1, int lineType = cv::LINE_8, int shift = 0);

	void AS_MATH_API drawCircle(cv::Mat& mat, const AsMathCircle& circle, const cv::Scalar& color = AsMathColor::_default, int thickness = 1, int lineType = cv::LINE_8, int shift = 0);

	cv::Mat AS_MATH_API visualizationPoints(const std::vector<cv::Point2i>& points, const cv::Scalar& pointColor = AsMathColor::_default, int radius = 0, double magnification = 1.0, int extend = 0);

	cv::Mat AS_MATH_API visualizationPoints(const std::vector<cv::Point2f>& points, const cv::Scalar& pointColor = AsMathColor::_default, int radius = 0, double magnification = 1.0, int extend = 0);

};