﻿#pragma once
#include "AsAlgorithmGlobal.h"
#include "AsContainer.h"
#include "AsAlgorithmParameter.h"

typedef void(*AAFunction)(const AsContainer& input, AsContainer& output);
typedef void(*AAFunctionA)(AsContainer& conta);
typedef void(*AAFunctionB)(AsAlgorithmParameter& conta);

__AS_JY(Update 2023.1.8)
class AS_ALGORITHM_EXPORT AsAlgorithmExecutor {
public:
	AsAlgorithmExecutor();
	AsAlgorithmExecutor(const std::string& dllname);
	virtual ~AsAlgorithmExecutor();

private:
	AAFunction mFunc;
	AsContainer mInput;
	AsContainer mOutput;

public:
	void setDllName(const std::string& dllname);

protected:
	virtual void toInput(AsContainer& input);
	virtual void fromOutput(const AsContainer& output);

public:
	AsContainer& getInput();
	AsContainer& getOutput();

public:
	bool execute();
	bool execute(const AsContainer& input, AsContainer& output);

public:
	static bool execute(const std::string& dllname, const AsContainer& input, AsContainer& output);

};

__AS_JY(Update 2023.3.9)
class AS_ALGORITHM_EXPORT AsAlgorithmExecutorA {
public:
	AsAlgorithmExecutorA();
	AsAlgorithmExecutorA(const std::string& dllname);
	virtual ~AsAlgorithmExecutorA();

private:
	AAFunctionA mFunc;
	AsContainer mConta;

public:
	void setDllName(const std::string& dllname);

protected:
	virtual void toInput(AsContainer& conta);
	virtual void fromOutput(const AsContainer& conta);

public:
	AsContainer& conta();

public:
	bool execute();
	bool execute(AsContainer& conta);

public:
	static bool execute(const std::string& dllname, AsContainer& conta);

};

__AS_JY(Update 2023.3.9)
class AS_ALGORITHM_EXPORT AsAlgorithmExecutorB {
public:
	AsAlgorithmExecutorB();
	AsAlgorithmExecutorB(const std::string& dllname);
	virtual ~AsAlgorithmExecutorB();

private:
	AAFunctionB mFunc;
	AsAlgorithmParameter mParameter;

public:
	void setDllName(const std::string& dllname);
	void setFunctionOption(int functionOption);

protected:
	virtual void toParameter(AsAlgorithmParameter& conta);
	virtual void fromParameter(const AsAlgorithmParameter& conta);

public:
	AsAlgorithmParameter& parameter();

public:
	bool execute();
	bool execute(AsAlgorithmParameter& conta);

public:
	static bool execute(const std::string& dllname, AsAlgorithmParameter& conta);

};