﻿#pragma once
#include "AsCvDefine.h"

namespace AsCv {

	/**
	 * @Desc 自动灰度映射
	 * @param
	 *	-input:输入图像
	 *	-output:输出图像
	 */
	AS_ALGORITHM_EXPORT void autoGrayMap(const cv::Mat& input, cv::Mat& output, int minGray = 30);

	/**
	 * @Desc 灰度映射
	 * @param
	 *	-input:输入图像
	 *	-output:输出图像
	 *	-min:映射区间的最小值
	 *	-max:映射区间的最大值
	 */
	AS_ALGORITHM_EXPORT void grayMap(const cv::Mat& input, cv::Mat& output, double min, double max,int minGray = 30);

	/**
	 * @Desc 获取图像的灰度图拷贝
	 * @param
	 *	-input:输入图像，灰度或彩色图
	 */
	AS_ALGORITHM_EXPORT cv::Mat getGrayMat(const cv::Mat& input);

	/**
	 * @Desc 获取图像的彩色图拷贝
	 * @param
	 *	-input:输入图像，灰度或彩色图
	 */
	AS_ALGORITHM_EXPORT cv::Mat getColorMat(const cv::Mat& input);

};
