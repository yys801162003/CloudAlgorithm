﻿#pragma once
#pragma warning(disable : 4099)
#pragma warning(disable : 4244)
#pragma warning(disable : 4251)
#pragma warning(disable : 4267)
#ifndef BUILD_STATIC
# if defined(ASALGORITHM_LIB)
#  define AS_ALGORITHM_EXPORT __declspec(dllexport)
# else
#  define AS_ALGORITHM_EXPORT __declspec(dllimport)
# endif
#else
# define AS_ALGORITHM_EXPORT
#endif
