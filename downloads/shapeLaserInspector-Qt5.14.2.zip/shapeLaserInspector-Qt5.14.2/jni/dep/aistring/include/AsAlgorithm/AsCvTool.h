﻿#pragma once
#include "AsCvDefine.h"

namespace AsCv {

	/**
	 * @desc 合并点集
	 * @param
	 *	-vAll:最终存放数据的点集
	 *	-v1:待合并到结果的点集
	 *	-offset:待合并点的整体偏移量
	 *	-bInver:是否转置xy，true为转置，false不转置
	 */
	AS_ALGORITHM_EXPORT extern void mergePoints(std::vector<cv::Point2i>& vAll, const std::vector<cv::Point2i>& v1, cv::Point2i offset, bool bInver = false);

	/**
	 * @desc 从指定点集中随机获取num个点
	 */
	AS_ALGORITHM_EXPORT extern std::vector<cv::Point2i> getRandomPoints(const std::vector<cv::Point2i>& vPoint, int num);

	/**
	 * @desc 从指定点集中随机获取1个点
	 */
	AS_ALGORITHM_EXPORT extern cv::Point2i getRandomPoint(const std::vector<cv::Point2i>& vPoint);

	/**
	 * @desc 与X合并得到点集
	 * @param
	 *	-mat:输入图像，必须是行矩阵
	 *	-fillNAN:是否给无值的地方自动填充NAN
	 */
	AS_ALGORITHM_EXPORT extern std::vector<cv::Point2d> getVectorPointsMergeX(const cv::Mat& mat, bool fillNan = false);

	/**
	 * @desc Mat转Vector
	 */
	template<typename _TYPE>
	std::vector<_TYPE> mat2Vector(const cv::Mat& mat) 
	{
		return (std::vector<_TYPE>)(mat.reshape(1, 1));
	}

	/**
	 * @desc 统计Mat最大最小值
	 * @param
	 *	-mat:输入图像，必须是行矩阵
	 */
	AS_ALGORITHM_EXPORT extern void staticMinMax(const cv::Mat& mat, double& min, double& max);

	/**
	 * @desc 统计Mat最大最小值，重载
	 * @param
	 *	-mat:输入图像，必须是行矩阵
	 */
	AS_ALGORITHM_EXPORT extern void staticMinMax(const cv::Mat& mat, int& min, int& max);

	/**
	 * @desc 统计点集最大最小值，重载
	 * @param
	 *	-mat:输入图像，必须是行矩阵
	 */
	AS_ALGORITHM_EXPORT extern void staticRange(const std::vector<cv::Point2f>& points,
		float& minX, float& maxX, float& minY, float& maxY);

	/**
	 * @desc 统计点集最大最小值，重载
	 * @param
	 *	-mat:输入图像，必须是行矩阵
	 */
	AS_ALGORITHM_EXPORT extern void staticRange(const std::vector<cv::Point>& points,
		int& minX, int& maxX, int& minY, int& maxY);

	/**
	 * @desc 点分割
	 * @param
	 *	-vPoint:输入点集
	 *	-direction:方向 0-X方向 1-Y方向
	 *	-step:间距
	 */
	AS_ALGORITHM_EXPORT extern std::vector<std::vector<cv::Point2f>> splitPoints(const std::vector<cv::Point2f>& vPoint, int direction, float step);

	/**
	 * @desc 计算平均灰度
	 */
	AS_ALGORITHM_EXPORT extern double getMeanGray(const cv::Mat& mat);

};

