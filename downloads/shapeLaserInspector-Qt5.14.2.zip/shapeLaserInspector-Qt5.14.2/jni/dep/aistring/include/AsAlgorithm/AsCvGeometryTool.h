﻿#pragma once
#include "AsCvDefine.h"

namespace AsCv {
	/**
	 * @desc 线平移
	 */
	AS_ALGORITHM_EXPORT void moveLine(Line& line, cv::Point2d transform);

	/**
	 * @desc 面平移
	 */
	AS_ALGORITHM_EXPORT void moveFace(Face& face, cv::Point3d transform);

	/**
	 * @desc 作平行线
	 */
	AS_ALGORITHM_EXPORT Line getParallelLine(const Line& line, const cv::Point2d& point);

	/**
	 * @desc 竖直线
	 */
	AS_ALGORITHM_EXPORT Line verticalLine(double x);

	/**
	 * @desc 水平线
	 */
	AS_ALGORITHM_EXPORT Line horizontalLine(double y);

	/**
	 * 求穿过两点的直线
	 */
	AS_ALGORITHM_EXPORT Line getLine(const cv::Point2i& pt1, const cv::Point2i& pt2);

	/**
	 * @desc 判断一个点是否在一条线的上方
	 */
	AS_ALGORITHM_EXPORT bool isAboveLine(const cv::Point2i& pt, const Line& line);

	/**
	* @desc 判断一个点是否在一条线的右方
	*/
	AS_ALGORITHM_EXPORT bool isOnRightOfLine(const cv::Point2i& pt, const Line& line);

	/**
	 * @desc 标准化线
	 */
	AS_ALGORITHM_EXPORT void normalize(Line& line);

}

