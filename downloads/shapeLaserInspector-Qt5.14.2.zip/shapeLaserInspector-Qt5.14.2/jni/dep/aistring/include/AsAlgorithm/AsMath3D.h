#include "AsMathBasic.h"

namespace AsMath {

	void AS_MATH_API translate(const std::vector<cv::Point3f>& inputPoints, std::vector<cv::Point3f>& outputPoints, cv::Vec3d distance);

	void AS_MATH_API rotate(const std::vector<cv::Point3f>& inputPoints, std::vector<cv::Point3f>& outputPoints, cv::Vec3d srcVector, cv::Vec3d dstVector);

	void AS_MATH_API rotateTranslate(const std::vector<cv::Point3f>& inputPoints, std::vector<cv::Point3f>& outputPoints, cv::Vec3d srcVector, cv::Vec3d dstVector, cv::Vec3d distance);

};