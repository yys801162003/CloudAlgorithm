﻿#pragma once
#include "AsAlgorithmGlobal.h"
#include "AsDefine.h"

namespace AsCv {

	// 2d直线ax+by+c=0
	struct Line {
		Line() :a(1.f), b(0.f), c(0.f) {}
		Line(double a, double b, double c) :a(a), b(b), c(c) {}
		double a;		//线参数a
		double b;		//线参数b
		double c;		//线参数c

	};

	// 面的表示ax+by+cz+d=0;
	struct Face
	{
		Face() :a(1.f), b(0.f), c(0.f), d(0.f) {}
		Face(double a, double b, double c, double d) :a(a), b(b), c(c), d(d) {}
		double a;		//线参数a
		double b;		//线参数b
		double c;		//线参数c
		double d;		//线参数d
	};

	// 圆
	struct Circle
	{
		Circle() :centerX(0.f), centerY(0.f), radius(1.f) {}
		Circle(double x, double y, double r) :centerX(x), centerY(y), radius(r) {}
		double centerX;		//圆心X坐标
		double centerY;		//圆心Y坐标
		double radius;		//半径
		inline cv::Point2d center() const { return cv::Point2d(centerX, centerY); }
	};

};
