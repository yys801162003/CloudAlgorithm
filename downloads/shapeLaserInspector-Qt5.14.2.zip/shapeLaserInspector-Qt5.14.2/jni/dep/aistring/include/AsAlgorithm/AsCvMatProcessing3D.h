﻿#pragma once
#include "AsCvDefine.h"

namespace AsCv {

	/**
	 * @desc 在一个浮点矩阵中找到最大的Z(图形学上)
	 */
	AS_ALGORITHM_EXPORT int findHighestZ(const cv::Mat& input, double& z);

}