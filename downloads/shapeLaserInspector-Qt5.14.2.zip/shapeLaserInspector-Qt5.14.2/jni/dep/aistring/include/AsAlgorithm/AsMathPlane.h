﻿#pragma once
#include "AsMathBasic.h"

class AS_MATH_API AsMathPlane {
public:
	AsMathPlane();
	AsMathPlane(double A, double B, double C, double D);
	AsMathPlane(const cv::Point3f& p1, const cv::Point3f& p2, const cv::Point3f& p3);
	AsMathPlane(const cv::Vec3f& vecNormal, const cv::Point3f& p);

private:
	double mA;
	double mB;
	double mC;
	double mD;
	double mDeno;

public:
	std::string tostr() const;

public:
	void setA(double A);
	void setB(double B);
	void setC(double C);
	void setD(double D);
	void reverse();

public:
	double getA() const;
	double getB() const;
	double getC() const;
	double getD() const;
	cv::Vec3f getNormal() const;

public:
	double calcDistance(const float x, const float y, const float z) const;
	double calcDistance(const cv::Point3f& pos) const;
	double calcDistanceSigned(const cv::Point3f& pos) const;
	double calcRadian(const cv::Vec3f& vec) const;
	cv::Mat calcRotationMat(const cv::Vec3f& dstNormalVec) const;

public:
	std::vector<cv::Point3f> getNearbyPoints(const std::vector<cv::Point3f>& inputPoints, const double dist_thresh) const ;

};
