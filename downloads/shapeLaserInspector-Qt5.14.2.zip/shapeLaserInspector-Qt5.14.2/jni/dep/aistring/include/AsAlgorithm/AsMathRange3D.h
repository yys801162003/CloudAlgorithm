﻿#pragma once
#include "AsMathBasic.h"

class AS_MATH_API AsMathRange3D {
public:
	AsMathRange3D();
	AsMathRange3D(double minX, double maxX, double minY, double maxY, double minZ, double maxZ);

private:
	double mMinX;
	double mMinY;
	double mMinZ;
	double mMaxX;
	double mMaxY;
	double mMaxZ;

public:
	std::string tostr() const;
	double getMinX() const;
	double getMinY() const;
	double getMinZ() const;
	double getMaxX() const;
	double getMaxY() const;
	double getMaxZ() const;
	double getLengthX() const;
	double getLengthY() const;
	double getLengthZ() const;

public:
	inline bool contains(const cv::Point3f& point);

public:
	inline void adjustX(double x);
	inline void adjustY(double y);
	inline void adjustZ(double z);
	inline void adjustXY(const cv::Point2f& point);
	inline void adjustXZ(const cv::Point2f& point);
	inline void adjustYZ(const cv::Point2f& point);
	inline void adjustXYZ(const cv::Point3f& point);

	void adjust(const std::vector<cv::Point3f>& points, bool reset = true);
	void adjustXY(const std::vector<cv::Point2i>& points, bool reset = true);
	void adjustXY(const std::vector<cv::Point2f>& points, bool reset = true);

public:
	void reset(double minX = 0, double maxX = 0, double minY = 0, double maxY = 0, double minZ = 0, double maxZ = 0);
	void reset(const cv::Point3f& point);
	void resetXY(const cv::Point2f& point);
	void resetZ(double z);

public:
	AsMathRange3D operator*(double n);
	AsMathRange3D operator*=(double n);

};
