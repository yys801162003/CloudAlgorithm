﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsBinder.hpp"
#include "AsSharedObject.hpp"
#include "AsDefine.h"

#define AW_SIGNALS_CLASS(OBJECT) AsWindowNamespace::AS_SIGNALS_CLASS(AsWindowProgress)

namespace AsWindowNamespace {

};

namespace AW = AsWindowNamespace;
