﻿#pragma once

/**
 * 串口业务封装类
 * 使用时请继承本类，并实现dataHandle方法
 */
#include <QObject>
#include <QThread>
#include "AsThread.h"
#include "AsCoreGlobal.h"

class QSerialPort;
class AS_CORE_EXPORT AsSerialPort  : public QObject {
	Q_OBJECT
public:
	AsSerialPort(QObject *parent = nullptr);
	~AsSerialPort();

	inline void setPortName(QString portName) { m_qsPortName = portName; }
	inline void setBaudRate(int baudRate) { m_iBaudRate = baudRate; }		//设置波特率

	void open();
	void close();
	void sendData(const QByteArray& data);
	void sendHexData(const QByteArray& hexData);

private slots:
	void onRecevieData();

protected:
	virtual void dataHandle(const QByteArray& data);			//数据处理

private:
	AsThread*		m_pThread;
	QSerialPort*	m_pPort;
	int				m_iBaudRate;
	QString			m_qsPortName;

};
