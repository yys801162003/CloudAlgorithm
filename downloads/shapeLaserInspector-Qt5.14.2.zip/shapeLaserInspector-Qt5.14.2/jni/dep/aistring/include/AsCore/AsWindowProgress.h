﻿#pragma once
#include "AsWindowBasics.h"

__AS_JY(2023.5.20)

namespace AsWindowNamespace {
	struct AS_CORE_EXPORT AS_SIGNALS_CLASS(AsWindowProgress) : public QObject {
		Q_OBJECT
	signals:
		void completed();
		void cancel();
	};
};

AS_MEMBER_CLASS_DECLARATION(AsWindowProgress);

class AS_CORE_EXPORT AsWindowProgress : public AS_SHARED_OBJECT(AsWindowProgress) {
public:
	AsWindowProgress(QWidget* parent = nullptr);

public:
	void start(QString infomation);
	void finish(QString infomation = "", int delay = 0) const;
	void updateProgress(float scale) const;
	void updateProgress(float scale, QString infomation) const;
	void updateProgress(QString infomation) const;

public:
	void setWindowSize(QSize size);

	void setEstimatedTime(int ms);
	void setUpdateIntervalTime(int ms);

	void setBackgroundColor(QColor color);
	void setBorderColor(QColor color);
	void setFont(QFont font);

	void setEnable_Modal(bool isEnable = true);
	void setEnable_CancelButton(bool isEnable = true);

public:
	int getElapsedTime() const;

private:
	AW_SIGNALS_CLASS(AsWindowProgress)* sigs();

public:
	template <typename _Lambda>
	void bindCompleted(_Lambda lambda) {
		QObject::connect(sigs(), &AW_SIGNALS_CLASS(AsWindowProgress)::completed, lambda);
	}
	template <typename _Lambda>
	void bindCancel(_Lambda lambda) {
		setEnable_CancelButton();
		QObject::connect(sigs(), &AW_SIGNALS_CLASS(AsWindowProgress)::cancel, lambda);
	}

};

namespace AsWindowNamespace {

	typedef AsWindowProgress Progress;
};