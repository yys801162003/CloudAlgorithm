﻿#pragma once
#include <opencv2/opencv.hpp>
#include <QString>
#include <QImage>
#include "AsCoreGlobal.h"

class ASCORE_EXPORT AsFileParser
{
public:
	virtual ~AsFileParser(){}

	//解析文件为cv::Mat类型
	virtual cv::Mat parseFileTocvMat(QString fileName) = 0;

	/**
	 * 转换为可显示的图像
	 */
	virtual QImage getDislpayImage(QString fileName) = 0;

	/**
	 * 转换为可显示的图像
	 */
	virtual cv::Mat getDislpayMat(QString fileName) = 0;

};

