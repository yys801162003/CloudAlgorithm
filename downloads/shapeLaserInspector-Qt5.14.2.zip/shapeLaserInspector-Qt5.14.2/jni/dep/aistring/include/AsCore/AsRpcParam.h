﻿#pragma once
#include <QJsonObject>
#include "AsJsonObject.h"
#include "AsCoreGlobal.h"

// 调用参数
class AS_CORE_EXPORT AsRpcParam :public AsJsonObject
{

public:
	QString	taskId;			// 任务Id
	int		type;			// 类型
	QString inputSrc;		// 输入源（图片等）
	QString	inputParams;	// 输入参数
	QString outputResult;	// 输出结果

public:
	AsRpcParam();
	~AsRpcParam();
	bool isEmpty();
	virtual void onBuildStructure()const override;
};

typedef void(*AsRpcCallBack)(const AsRpcParam& result);