﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsDefine.h"
#include "AsBinder.hpp"
#include <QWidget>

AS_MEMBER_CLASS_DECLARATION(AsWidgetValuesAdjuster);

class AS_CORE_EXPORT AsWidgetValuesAdjuster : public QWidget, public AsBinder<AsWidgetValuesAdjuster> {
	Q_OBJECT

public:
	AsWidgetValuesAdjuster(QWidget* parent = nullptr);
	~AsWidgetValuesAdjuster();

private:
	AS_MEMBER_CLASS(AsWidgetValuesAdjuster)* mp;

public:
	int getValue(const QString& name);
	double getDoubleValue(const QString& name);

public:
	void addOptionValue(const QString& name, int value, int minValue = 0, int maxValue = 100);
	void addOptionValue(const QString& name, double value, double minValue = 0.0, double maxValue = 100.0);
	void removeOptionValue(const QString& name);
	void clearOptionValues();

signals:
	void sigValueChanged(QString name, int value);
	void sigDoubleValueChanged(QString name, double value);

};

