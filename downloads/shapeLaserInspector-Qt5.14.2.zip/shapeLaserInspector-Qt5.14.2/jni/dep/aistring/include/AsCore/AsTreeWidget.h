﻿#pragma once
#include "AsCoreGlobal.h"
#include <QTreeWidget>

class AS_CORE_EXPORT AsTreeWidget : public QTreeWidget {
	Q_OBJECT

public:
	friend class AsTreeController;
	explicit AsTreeWidget(QWidget *parent);

private:
	void dragEnterEvent(QDragEnterEvent* e) override;
	void dragMoveEvent(QDragMoveEvent* e) override;
	void dragLeaveEvent(QDragLeaveEvent* e) override;
	void dropEvent(QDropEvent* e) override;

signals:
	void sigCurrentItemChanged(QTreeWidgetItem* current, QTreeWidgetItem *previous);
	void sigItemActivated(QTreeWidgetItem* item, int column);
	void sigItemEntered(QTreeWidgetItem* item, int column);
	void sigItemChanged(QTreeWidgetItem* item, int column);
	void sigItemPressed(QTreeWidgetItem* item);
	void sigItemClicked(QTreeWidgetItem* item, int column);
	void sigItemDoubleClicked(QTreeWidgetItem* item, int column);
	void sigItemExpanded(QTreeWidgetItem* item);
	void sigItemCollapsed(QTreeWidgetItem* item);
	void sigItemSelectionChanged();
	void sigFileDragIn(QString filename);

private:
	void initSignals();

};

