﻿#pragma once
#include "AsCoreGlobal.h"
#include <QObject>
#include <QThread>
#include "AsDefine.h"

class AsThreadWork;

class AS_CORE_EXPORT AsThread : public QObject {
	Q_OBJECT

public:
	AsThread(QObject* parent = nullptr);
	~AsThread();

signals:
	void signalFinished();

private:
	QThread			m_thread;
	AsThreadWork*	m_pWork;

public:
	void invokeFn(QObject* obj, const QString &fn);
	void invokeFn(QObject* obj, const QString &fn,const QVariantList& params);

	void invokeFn(AsVoidFunc fn);
	void blockingInvokeFn(AsVoidFunc fn);
};

AS_MEMBER_CLASS_DECLARATION(AsFlexThread);
class AS_CORE_EXPORT AsFlexThread : public QObject
{
	Q_OBJECT

public:
	AsFlexThread(QObject* parent = nullptr);
	~AsFlexThread();

private:
	AS_MEMBER_CLASS(AsFlexThread)* m_pPrivate;

public:
	void invokeFn(QObject* obj, const QString &fn, const QVariantList& params);
};
