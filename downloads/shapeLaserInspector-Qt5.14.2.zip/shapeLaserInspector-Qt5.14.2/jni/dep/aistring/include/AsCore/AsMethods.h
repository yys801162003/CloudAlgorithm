﻿#pragma once
#include "AsMethodT.hpp"

#include "AsBasicMethod.h"

#include "AsMethodFile.h"

#include "AsMethodByte.h"

#include "AsMethodMath.h"

#include "AsMethodOpencv.h"

#include "AsMethodString.h"

#include "AsMethodImage.h"

#include "AsMethodDebug.h"
