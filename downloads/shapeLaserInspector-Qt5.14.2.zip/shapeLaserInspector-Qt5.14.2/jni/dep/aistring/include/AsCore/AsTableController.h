﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsBinder.hpp"
#include "AsTableWidget.h"
#include "AsDefine.h"
#include <QVector>
#include <QPushButton>
#include <QLineEdit>
#include <QCheckBox>
#include <QTextEdit>
#include <QShowEvent>
#include <QResizeEvent>

AS_MEMBER_CLASS_DECLARATION(AsTableController);

class AS_CORE_EXPORT AsTableController : public AsBinder<AsTableWidget> {

public:
	explicit AsTableController(AsTableWidget* core = nullptr);
	AsTableController(const AsTableController& con);
	~AsTableController();

private:
	AS_MEMBER_CLASS(AsTableController)* m;

public:
	AsTableWidget* core();
	void setCore(AsTableWidget* core);

public:
	void resize(int rows, int cols);
	void reset(const QVector<QString>& head, const QVector<QVector<QVariant>>& contents = QVector<QVector<QVariant>>());
	void reset(const QVector<QVector<QVariant>>& contents);

public:
	void config_align(int alignment);

public:
	void horhead_show();
	void horhead_hide();
	void horhead_set(int col, const QString& colname, int alignment = INT_MAX);

public:
	void verhead_show();
	void verhead_hide();
	void verhead_set(int row, const QString& rowname, int alignment = INT_MAX);

public:
	int row_size();
	void row_add();
	void row_add(const QVector<QVariant>& itemArray);
	void row_add(const QVector<QString>& itemArray);
	void row_update(int row, const QVector<QVariant>& itemArray);
	void row_insert(int row, const QVector<QVariant>& itemArray);
	void row_insert(int row, const QVector<QString>& itemArray);
	void row_remove(int row);
	void row_clear();
	QVector<QTableWidgetItem*> row_items(int row);

public:
	int col_size();
	void col_add();
	void col_add(const QString& colname = QString());
	void col_add(const QVector<QString>& colnameArray);
	void col_insert(int col, const QString& colname = QString());
	void col_remove(int col);
	void col_clear();
	QVector<QTableWidgetItem*> col_items(int col);
	void col_setEditable(int col, bool isEditable);
	void col_fitWidths();
	void col_fitWidths(const QVector<float>& weights);

public:
	QTableWidgetItem* cell(int row, int col);
	QString cell_str(int row, int col);
	QTableWidgetItem* cell_set(int row, int col, const QString &text, int alignment = INT_MAX);
	void cell_set(int row, int col, QWidget* widget);
	QPushButton* cell_setPushButton(int row, int col, const QString& text);
	QLineEdit* cell_setLineEdit(int row, int col, const QString& text);
	QCheckBox* cell_setCheckBox(int row, int col, bool isChecked);
	QTextEdit* cell_setTextEdit(int row, int col, const QString& text);

public:
	QList<QString> getHeadList();
	QVector<QString> getHeadVector();
	QList<QList<QString>> getTableLists();
	QVector<QVector<QString>> getTableVectors();

public:
	bool hasSelected();
	int currentRow();
	void cancelSelect();

};

