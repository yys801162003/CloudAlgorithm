﻿#pragma once
#include "AsCoreGlobal.h"

class AS_CORE_EXPORT AsCsvFile {
public:
	AsCsvFile();
	AsCsvFile(const QString &filename);

private:
	QString					m_filename;
	QList<QList<QString>>	m_contents;
	int						m_nBeginRow;

public:
	void setBeginRow(int beginRow);
	bool load(const QString &filename = QString());
	bool save(const QString &filename = QString());

public:
	bool getContents(QList<QList<QString>> &content);
	bool getContents(QVector<QVector<QString>> &content);
	QString getContent(int row, int col);
	bool setContents(const QList<QList<QString>> &content);
	bool setContents(const QVector<QVector<QString>> &content);
	bool setContent(int row, int col, const QString &content);
	void resizeContents(int rows, int cols);
	void clearContents();

};
