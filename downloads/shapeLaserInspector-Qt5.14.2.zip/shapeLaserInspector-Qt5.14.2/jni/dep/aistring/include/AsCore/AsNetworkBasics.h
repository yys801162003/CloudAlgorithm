﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsDefine.h"
#include "AsBinder.hpp"
#include <AsQException.h>
#include <QByteArray>
#include <QString>
#include <QVector>
#include <QMetaMethod>
#include <QTcpSocket>

class QTcpSocket;

namespace AsNetwork {

	enum DataType {
		Null,
		Bit8,
		Bit16,
		Bit32,
		Bit64,
		String,
		ByteArray
	};

	template <typename _Type>
	_Type& ref(void* ptr) {
		return *reinterpret_cast<_Type*>(ptr);
	}
	template <typename _Type>
	_Type* ptr(void* ptr) {
		return reinterpret_cast<_Type*>(ptr);
	}
	template <typename _Type>
	_Type* ncopy(const _Type& data) {
		return new _Type(data);
	}
	
	extern inline void pushToByteArray(QByteArray& byteArray, char val);
	extern inline void pushToByteArray(QByteArray& byteArray, short val);
	extern inline void pushToByteArray(QByteArray& byteArray, int val);
	extern inline void pushToByteArray(QByteArray& byteArray, long long val);
	extern inline void pushToByteArray(QByteArray& byteArray, const QString& val);
	extern inline void pushToByteArray(QByteArray& byteArray, const QByteArray& val);

	extern inline void fromByteArray(QByteArray& byteArray, int& index, char& val);
	extern inline void fromByteArray(QByteArray& byteArray, int& index, short& val);
	extern inline void fromByteArray(QByteArray& byteArray, int& index, int& val);
	extern inline void fromByteArray(QByteArray& byteArray, int& index, long long& val);
	extern inline void fromByteArray(QByteArray& byteArray, int& index, QString& val);
	extern inline void fromByteArray(QByteArray& byteArray, int& index, QByteArray& val);

	AS_CORE_EXPORT QString toClientHost(QTcpSocket* socket);
};
