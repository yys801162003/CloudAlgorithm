﻿#pragma once
#include "AsEventBasics.h"

__AS_JY(2023.1.7)
class AS_CORE_EXPORT AsEventSink : public QObject, public AsBinder<AsEventSink> {
	Q_OBJECT

public:
	AsEventSink(QObject* parent = nullptr, bool enableEventsGather = false);
	~AsEventSink();

private:
	AS_MEMBER_CLASS(AsEventSink)* m;

private:
	bool eventFilter(QObject* object, QEvent* event) override;

public:
	void installTo(QObject* object);
	void installToApplication();
	void addReceiver(QObject* receiver);
	void addReceiverWindows();
	void removeReceiver(QObject* receiver);
	void removeReceiverWindows();
	void setEnableEventsGather(bool isEnable);
	QObject* currentReceiver();
	AsEvents* currentEvents();

signals:
	void sigShow(QShowEvent* event);
	void sigHide(QHideEvent* event);
	void sigClose(QCloseEvent* event);
	void sigResize(QResizeEvent* event);
	void sigPaint(QPaintEvent* event);
	void sigMove(QMoveEvent* event);
	void sigEnter(QEvent* event);
	void sigLeave(QEvent* event);
	void sigMousePress(QMouseEvent* event);
	void sigMouseRelease(QMouseEvent* event);
	void sigMouseDoubleClick(QMouseEvent* event);
	void sigMouseMove(QMouseEvent* event);
	void sigWheelRoll(QWheelEvent* event);
	void sigKeyPress(QKeyEvent* event);
	void sigKeyRelease(QKeyEvent* event);
	void sigFocusIn(QFocusEvent* event);
	void sigFocusOut(QFocusEvent* event);
	void sigContextMenu(QContextMenuEvent* event);
	void sigDragEnter(QDragEnterEvent* event);
	void sigDragMove(QDragMoveEvent* event);
	void sigDragLeave(QDragLeaveEvent* event);
	void sigDrop(QDropEvent* event);
	void sigCursorChange(QEvent* event);

};

