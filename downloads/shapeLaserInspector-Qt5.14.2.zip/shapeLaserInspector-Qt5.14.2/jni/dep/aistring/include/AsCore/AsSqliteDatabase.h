﻿#pragma once
#include "AsDatabaseBasics.h"

AS_MEMBER_CLASS_DECLARATION(AsSqliteDatabase);

class AS_CORE_EXPORT AsSqliteDatabase {
public:
	AsSqliteDatabase();
	virtual ~AsSqliteDatabase();

private:
	AS_MEMBER_CLASS(AsSqliteDatabase)* mp;

public:
	bool open(const QString& databaseName, const QString& username, const QString& password);
	void close();

protected:
	virtual void process(unsigned int option, QSqlQuery& q);

public:
	bool exec(const QString& sql);
	bool exec(const QString& sql, unsigned int option);
	void show();

public:
	QString lastError() const;

};
