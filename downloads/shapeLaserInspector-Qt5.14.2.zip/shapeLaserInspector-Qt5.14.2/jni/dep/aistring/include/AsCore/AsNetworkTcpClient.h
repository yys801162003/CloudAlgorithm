#pragma once
#include "AsNetworkMessage.h"

AS_MEMBER_CLASS_DECLARATION(AsNetworkTcpClient);

class AS_CORE_EXPORT AsNetworkTcpClient : public QObject, public AsBinder<AsNetworkTcpClient> {
	Q_OBJECT

public:
	explicit AsNetworkTcpClient(QObject* parent = nullptr);
	~AsNetworkTcpClient();
	
private:
	AS_MEMBER_CLASS(AsNetworkTcpClient)* mp;

public:
	QTcpSocket* socket();

public:
	void requestConnection(const QString& ip, quint16 port);
	void breakupConnection();			//断开连接 add by wj /time:0612
	void setSendingPeriod(int periodTime);

public:
	void sendMessage(const AsNetworkMessage& msg);
	bool takeMessage(AsNetworkMessage& msg);
	AsNetworkMessage takeMessage();

	void sendByteArray(const QByteArray& byteArray);
	bool takeByteArray(QByteArray& byteArray);

public:
	template <typename _Slot>
	void bindConnected(_Slot slot) {
		if (isSignalConnected(metaObject()->method(metaObject()->indexOfSignal("sigConnected()"))))
			unbindSignal(SIGNAL(sigConnected()));
		bindSignal(&AsNetworkTcpClient::sigConnected, this, slot);
	}
	template <typename _Slot>
	void bindDisconnected(_Slot slot) {
		if (isSignalConnected(metaObject()->method(metaObject()->indexOfSignal("sigDisconnected()"))))
			unbindSignal(SIGNAL(sigDisconnected()));
		bindSignal(&AsNetworkTcpClient::sigDisconnected, this, slot);
	}
	template <typename _Slot>
	void bindReceived(_Slot slot) {
		if (isSignalConnected(metaObject()->method(metaObject()->indexOfSignal("sigReceived()"))))
			unbindSignal(SIGNAL(sigReceived()));
		bindSignal(&AsNetworkTcpClient::sigReceived, this, slot);
	}

signals:
	void sigConnected();
	void sigDisconnected();
	void sigReceived();
	void sigError(int );

};

