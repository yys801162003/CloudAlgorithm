﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsBinder.hpp"
#include "AsCatcher.h"
#include <QShowEvent>
#include <QHideEvent>
#include <QCloseEvent>
#include <QResizeEvent>
#include <QPaintEvent>
#include <QMoveEvent>

class AsEvents;
AS_MEMBER_CLASS_DECLARATION(AsEvents);
AS_MEMBER_CLASS_DECLARATION(AsEventSink);

__AS_JY(2023.1.7)
namespace AsEventBasics {

	enum Flag {
		Unchange = -0x80000000
	};

	struct CoordSystem {
		enum Enum {
			Widget,
			Global,
			Local,
			Window,
			Screen
		};
	};

	struct Key {
		enum Enum {
			None = 0x00000000,
			MouseLeft = 0x00000001,
			MouseRight = 0x00000002,
			MouseMid = 0x00000004,
			MouseBack = 0x00000008,
			MouseForward = 0x00000010,
			Space = 0x20,
			Exclam,
			QuoteDbl,
			NumberSign,
			Dollar,
			Percent,
			Ampersand,
			Apostrophe,
			ParenLeft,
			ParenRight,
			Asterisk,
			Plus,
			Comma,
			Minus,
			Period,
			Slash,
			Num0, Num1, Num2, Num3, Num4, Num5, Num6, Num7, Num8, Num9,
			Colon,
			Semicolon,
			Less,
			Equal,
			Greater,
			Question,
			At,
			A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
			BracketLeft,
			Backslash,
			BracketRight,
			AsciiCircum,
			Underscore,
			QuoteLeft,
			BraceLeft = 0x7B,
			Bar,
			BraceRight,
			AsciiTilde,
			F1 = 0x01000030, F2, F3, F4, F5, F6, F7, F8, F9, F10,
			F11 = 0x0100003A, F12,
			Escape = 0x01000000,
			Tab,
			Backtab,
			Backspace,
			Return,
			Enter,
			Insert,
			Delete,
			Pause,
			Print,
			SysReq = 0x0100000A,
			Clear,
			Home = 0x01000010,
			End,
			Left,
			Up,
			Right,
			Down,
			PageUp,
			PageDn,
			Shift = 0x01000020,
			Control,
			Meta,
			Alt,
			CapsLock,
			NumLock,
			ScrollLock,
		};
		static QString toString(int key);
	};

};

namespace AE = AsEventBasics;

