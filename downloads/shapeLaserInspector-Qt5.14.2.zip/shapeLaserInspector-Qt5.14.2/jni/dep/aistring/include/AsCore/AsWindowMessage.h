﻿#pragma once
#include "AsWindowBasics.h"
#include "AsDefine.h"

__AS_JY(2023.1.7)
AS_MEMBER_CLASS_DECLARATION(AsWindowMessage);

class AS_CORE_EXPORT AsWindowMessage : public QObject {
	Q_OBJECT

public:
	AsWindowMessage(QWidget* parent, const QString& message);
	~AsWindowMessage();

private:
	AS_MEMBER_CLASS(AsWindowMessage)* m;

public:
	void setMessage(const QString& message);
	void setColorStyle(const QColor& fore, const QColor& back, const QColor& border);
	void setWindowSize(const QSize& size);

};

namespace AsWindowNamespace {
	typedef AsWindowMessage Message;
};