﻿#pragma once
#include "AsNetworkBasics.h"

AS_MEMBER_CLASS_DECLARATION(AsNetworkData);

class AS_CORE_EXPORT AsNetworkData {
public:
	AsNetworkData();
	AsNetworkData(char data);
	AsNetworkData(short data);
	AsNetworkData(int data);
	AsNetworkData(long long data);
	AsNetworkData(uint8_t data);
	AsNetworkData(uint16_t data);
	AsNetworkData(uint32_t data);
	AsNetworkData(uint64_t data);
	AsNetworkData(float data);
	AsNetworkData(double data);
	AsNetworkData(const QString& data);
	AsNetworkData(const QByteArray& data);
	AsNetworkData(const AsNetworkData& networkData);
	AsNetworkData& operator=(const AsNetworkData& networkData);

private:
	AS_MEMBER_CLASS(AsNetworkData)* mp;
	
public:
	bool isNull() const;
	int byteCount() const;
	int type() const;

private:
	void toByteArray(QByteArray& byteArray) const;
	void fromByteArray(QByteArray& bytes, int& index);

public:
	char toChar() const;
	short toShort() const;
	int toInt() const;
	qint64 toInt64() const;
	uint8_t toUInt8() const;
	uint16_t toUInt16() const;
	uint32_t toUInt32() const;
	uint64_t toUInt64() const;
	float toFloat() const;
	double toDouble() const;
	QString toQString() const;
	QByteArray toQByteArray() const;

public:
	friend class AsNetworkMessage;

};

