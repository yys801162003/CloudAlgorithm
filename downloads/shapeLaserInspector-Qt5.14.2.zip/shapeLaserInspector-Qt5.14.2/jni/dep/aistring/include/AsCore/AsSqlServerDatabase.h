﻿#pragma once
#include "AsDatabaseBasics.h"

AS_MEMBER_CLASS_DECLARATION(AsSqlServerDatabase);

class AS_CORE_EXPORT AsSqlServerDatabase {
public:
	AsSqlServerDatabase();
	virtual ~AsSqlServerDatabase();

private:
	AS_MEMBER_CLASS(AsSqlServerDatabase)* mp;

public:
	bool connect(const QString& server, const QString database, const QString& uid, const QString pwd);
	
protected:
	virtual void process(unsigned int option, QSqlQuery& q);

public:
	bool exec(const QString& sql);
	bool exec(const QString& sql, unsigned int option);
	void show();

public:
	QString lastError() const;

};
