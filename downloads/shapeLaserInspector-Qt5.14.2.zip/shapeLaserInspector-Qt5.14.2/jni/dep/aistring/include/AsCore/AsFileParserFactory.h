﻿#pragma once
#include "AsFileParser.h"
#include <QMap>


enum FileParserType
{
	Picture,//一般图片类型，包含：*.jpg *.png格式
	Apc,//apc格式图片
	Tif,//tif格式
};

class ASCORE_EXPORT AsFileParserFactory
{
public:
	AsFileParserFactory();
	~AsFileParserFactory();
	AsFileParser* getFileParser(enum FileParserType parserType);
private:
	QMap<int, AsFileParser*> m_fileParserMap;
};

