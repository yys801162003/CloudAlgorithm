﻿#pragma once
#include "AsCoreGlobal.h"
#include <QTimer>

/*
	【使用示例】
	AsExternalMemoryTimer* emTimer = new AsExternalMemoryTimer("自定义", this);		// 定义名称为“自定义”的定时器
	emTimer->resetCurrent_s(5);														// 从当前时间开始定时5秒
	connect(emTimer, &AsExternalMemoryTimer::sig_timeout, [&](int overtime) {		// 连接超时信号槽
		qDebug() << "time out, overtime:" << overtime;								// 输出超时时间
	});
	emTimer->start();																// 启动定时器
*/

// 外存定时器
class AS_CORE_EXPORT AsExternalMemoryTimer : public QObject {
	Q_OBJECT

public:
	explicit AsExternalMemoryTimer(QObject* parent = nullptr);
	AsExternalMemoryTimer(const QString& name, QObject* parent = nullptr);
	~AsExternalMemoryTimer();

private:
	QString m_name;
	int64_t m_startTime;
	int64_t m_cycleTime;
	QTimer* m_checker;

signals:
	// 超时信号
	void sig_timeout(int overtime_s);

private slots:
	void onTrrigerCheck();

public:
	// 获取名称
	QString getName();
	// 获取起始时间 - 返回秒
	int64_t getStartTime_s();
	// 获取起始时间	- 返回日期
	QDateTime getStartTime_dateTime();
	// 获取周期时间 - 返回秒
	int64_t getCycleTime_s();
	// 获取周期时间 - 返回天
	int getCycleTime_days();
	// 获取剩余时间 - 返回秒
	int64_t getRemainingTime_s();
	// 获取剩余时间 - 返回天
	int getRemainingTime_days();
	// 获取是否超时
	bool isTimeout();

public:
	// 开始执行
	void start(int msec = 1000);
	// 结束执行
	void stop();
	// 重置定时器
	void reset(const QDateTime& startTime, int64_t cycleTime_s);
	// 重置定时器
	void reset(const QDateTime& endTime);
	// 重置定时器
	void resetCurrent_s(int64_t cycleTime_s);
	// 重置定时器
	void resetCurrent_days(int cycleTime_days);
	// 设置起始时间
	void setStartTime(const QDateTime& startTime);
	// 设置周期时间
	void setCycleTime_s(int64_t cycleTime_s);
	// 设置周期时间
	void setCycleTime_days(int cycleTime_days);

};
