﻿#pragma once
#include "AsNetworkData.h"

AS_MEMBER_CLASS_DECLARATION(AsNetworkMessage);

class AS_CORE_EXPORT AsNetworkMessage {
public:
	AsNetworkMessage();
	AsNetworkMessage(const AsNetworkData& data);
	AsNetworkMessage(const QVector<AsNetworkData>& structure);
	AsNetworkMessage(const AsNetworkMessage& msg);
	virtual ~AsNetworkMessage();

private:
	AS_MEMBER_CLASS(AsNetworkMessage)* mp;

public:
	int count() const;
	const QVector<AsNetworkData>& datas() const;
	const AsNetworkData& data(int index) const;

public:
	virtual QByteArray toByteArray() const;
	virtual bool takeFromByteArray(QByteArray& bytes);

public:
	void reset(const QVector<AsNetworkData>& datas);
	void pushData(const AsNetworkData& data);
	void setData(int index, const AsNetworkData& data);
	
};
