﻿#pragma once

#include <QObject>
#include "AsCoreGlobal.h"
#include "AsRpcParam.h"
#include "AsDefine.h"

AS_MEMBER_CLASS_DECLARATION(AsRpcServer);

class AS_CORE_EXPORT AsRpcServer : public QObject
{
	Q_OBJECT

private:
	AS_MEMBER_CLASS(AsRpcServer)* mp;

public:
	explicit AsRpcServer(QObject *parent = nullptr);
	explicit AsRpcServer(quint16 serverPort,QObject *parent = nullptr);
	~AsRpcServer();

	// 开启服务
	void startRpcServer();

	// 开启监听者
	void startListener();

	// 关闭客户端
	void closeRpcClient(const QString& clientId);

	// 关闭所有客户端程序
	void closeAllRpcClient();

	// 设置服务端口
	void setServerPort(quint16 serverPort);

	// 设置客户端启动是否伴随窗体
	void setClientWithWindows(bool isWithWindows = true);

	// 设置监听者本地路径
	void setListenerLocalPath(const QString& localPath);

	// 注册服务程序
	void registerClientDll(const QString& clientId, const QString& dllId);

	// 回调式调用
	void callDll(const QString& dllId, const QString& method,AsRpcParam inputParam = AsRpcParam(), AsRpcCallBack callBackFun = nullptr);

	// 阻塞式调用
	AsRpcParam callDllBlocking(const QString& dllId,const QString& method,AsRpcParam inputParam = AsRpcParam());

signals:
	void sigRecvResult();
	
};
