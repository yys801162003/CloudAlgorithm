﻿#pragma once
#include "AsCoreGlobal.h"
#include <opencv2/opencv.hpp>
#include <QString>

class ASCORE_EXPORT AsJsonTypeHandler
{
public:
	virtual ~AsJsonTypeHandler() {}

	virtual QString toString(void* data) = 0;
	virtual void parseFromString(QString qstr, void* ptr) = 0;
};
