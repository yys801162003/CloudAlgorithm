﻿#pragma once
#include <QComboBox>	
#include <QObject>
#include <QTextEdit>
#include "AsCoreGlobal.h"

/************************************************************************/
/*                    一些常用的Ui控制器			                    */
/************************************************************************/
/**
 * 下拉框控制器
 */
class ASCORE_EXPORT AsComboxBoxController :public QObject
{
	Q_OBJECT
private:
	QComboBox*												m_pUi;
	bool													m_bSendUpdate;		//是否发送更新信号(防止互锁)

public:
	AsComboxBoxController(QComboBox* pComboBox, QObject* parent = nullptr);
	void clear();
	void setTextList(QStringList qsl);
	void addText(QString text);
	void setCurrentIndex(int index);

signals:
	void sigCurrentIndexChanged(int index);

};

/**
 * 键值对窗体控制器
 */
class AsKeyValueWidget;
class ASCORE_EXPORT AsKeyValueWidgetController :public QObject
{
private:
	AsKeyValueWidget*							m_pUi;	//Ui界面

public:
	AsKeyValueWidgetController(AsKeyValueWidget* pUi, QObject* parent = 0);

	void setValue(QString key, QString value);
	void setLabelProperty(QString labelKey, QString propertyKey, QVariant value);

};

/**
 * textEdit控制器
 */
class ASCORE_EXPORT AsTextEditController :public QObject
{
private:
	QTextEdit*									m_pUi;			//对应的Ui
	bool										m_isShowTime;	//时间控制
	QString										m_timeFormat;	//时间格式

public:
	AsTextEditController(QTextEdit* pUi, QObject* parent = nullptr);

	void setShowTime(bool bShow);								//设置是否显示时间
	void append(QString text, QColor color = Qt::black);		//按指定颜色添加文本
	void clear();												//清除所有文本

	void setMaxLineCount(int lineCount);						//设置最大行数
	void setWordWrap(bool bWordWrap);							//设置自动换行

};

namespace As {
	void ASCORE_EXPORT updateAsStyle(QWidget* p, QString style);
	void ASCORE_EXPORT updateAsState(QWidget* p, QString state);
}