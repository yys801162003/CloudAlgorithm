﻿#pragma once

#include "AsCoreGlobal.h"
#include "AsApcFile.h"

class ASCORE_EXPORT AsStaticMemberController
{
public:
	static void setApcFileParserMode(AsApcFile::StorageMode mode);
};

