﻿#pragma once
#include "AsCoreGlobal.h"
#include <QVector>

class AS_CORE_EXPORT AsApcFile {
public:
	enum StorageMode {
		LittleEndian,
		BigEndian
	};

public:
	AsApcFile();
	AsApcFile(const QString& filename);
	AsApcFile(const QString& filename, StorageMode mode);

private:
	QString				m_filename;
	QVector<float>		m_pointCloud;
	int					m_width;
	int					m_height;
	bool				m_BigEndian_Or_LittleEndian;

public:
	void SetStorageMode(StorageMode mode);

public:
	bool load(const QString& filename = QString());
	bool load(QVector<float>& pointCloud, int& width, int& height, const QString& filename = QString());
	bool save(const QString& filename = QString());
	bool save(const QVector<float>& pointCloud, int width, int height, const QString& filename = QString());

public:
	void GetPointCloud(QVector<float>& pointCloud, int& width, int& height);
	void SetPointCloud(const QVector<float>& pointCloud, int width, int height);

};
