﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsDefine.h"
#include <QVariant>

// [Title] AsTableModelRow 表格模型片段（基类）

class AS_CORE_EXPORT AsTableModelRow {
public:
	virtual ~AsTableModelRow();

public:
	virtual QStringList getFields() = 0;
	virtual QVariantList getValueList() = 0;
	virtual QVariantList getColorList();


};
