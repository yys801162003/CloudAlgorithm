﻿#pragma once

#ifndef BUILD_STATIC
# if defined(ASCORE_LIB)
#  define ASCORE_EXPORT Q_DECL_EXPORT
# else
#  define ASCORE_EXPORT Q_DECL_IMPORT
# endif
#else
# define ASCORE_EXPORT
#endif

#define AS_CORE_EXPORT ASCORE_EXPORT

#include <QtCore/qglobal.h>
#include <QString>
#include <QList>
#include <QVector>
#include <QDebug>
#include "AsBasicGlobal.h"

#define AS_BIND_SPINBOX(UI_PTR, VAR) \
	UI_PTR->setValue(VAR); \
	connect(UI_PTR, QOverload<int>::of(&QSpinBox::valueChanged), [&](int value) { \
		VAR = value; \
	})
#define AS_BIND_DOUBLESPINBOX(UI_PTR, VAR) \
	UI_PTR->setValue(VAR); \
	connect(UI_PTR, QOverload<double>::of(&QDoubleSpinBox::valueChanged), [&](int value) { \
		VAR = value; \
	})
