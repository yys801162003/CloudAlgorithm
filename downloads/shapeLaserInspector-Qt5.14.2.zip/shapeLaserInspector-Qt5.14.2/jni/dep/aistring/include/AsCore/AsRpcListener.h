#pragma once

#include <QObject>
#include "AsCoreGlobal.h"
#include "AsDefine.h"

AS_MEMBER_CLASS_DECLARATION(AsRpcListener);

class AS_CORE_EXPORT AsRpcListener  : public QObject
{
	Q_OBJECT
private:
	AS_MEMBER_CLASS(AsRpcListener)* mp;

public:
	explicit AsRpcListener(QObject *parent = nullptr);
	~AsRpcListener();

	// 连接服务器
	void linkServer();

	// 设置服务器Host地址
	void setServerHost(const QString& serverIp, const quint16& serverPort);

signals:
	void sigClientOnline(const QString& clientId);
	void sigClientOffline(const QString& clientId);

};
