﻿#pragma once
#include "AsCoreGlobal.h"
#include <QPixmap>

__AS_JY(Update 2023.01.07)
namespace As {

	// 获取屏幕截图（屏幕区域）
	AS_CORE_EXPORT QPixmap ScreenCapture(const QRect& rect);
	// 获取全屏截屏图
	AS_CORE_EXPORT QPixmap FullScreenCapture();

};