﻿#pragma once
#include "AsCoreGlobal.h"

// CV::Mat序列化与反序列化
ASCORE_EXPORT QDataStream &operator<<(QDataStream &stream, const cv::Mat& mat);
ASCORE_EXPORT QDataStream &operator>>(QDataStream &stream, cv::Mat& mat);

// cv::Point序列化与反序列化
ASCORE_EXPORT QDataStream &operator<<(QDataStream &stream, const cv::Point& cvPoint);
ASCORE_EXPORT QDataStream &operator>>(QDataStream &stream, cv::Point& cvPoint);

// cv::Rect序列化与反序列化
ASCORE_EXPORT QDataStream &operator<<(QDataStream &stream, const cv::Rect& cvRect);
ASCORE_EXPORT QDataStream &operator>>(QDataStream &stream, cv::Rect& cvRect);


// std::vector序列化与返序列化
template <typename T>
QDataStream& operator<<(QDataStream &output, const std::vector<T>& vData)
{
	output << static_cast<qint32>(vData.size());
	for (auto data : vData)
	{
		output << data;
	}
	return output;
};

template <typename T>
QDataStream &operator>>(QDataStream &intput, std::vector<T>& vData)
{
	qint32 vSize = 0;
	intput >> vSize;
	for (int i = 0; i < vSize; i++)
	{
		T data;
		intput >> data;
		vData.push_back(data);
	}
	return intput;
};



