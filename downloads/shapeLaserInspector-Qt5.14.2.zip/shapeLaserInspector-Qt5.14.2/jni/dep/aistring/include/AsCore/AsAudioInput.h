﻿#pragma once
#include "AsDefine.h"
#include "AsBinder.hpp"
#include "AsCoreGlobal.h"

AS_MEMBER_CLASS_DECLARATION(AsAudioInput);

class AS_CORE_EXPORT AsAudioInput : public QObject, public AsBinder<AsAudioInput> {
	Q_OBJECT

public:
	AsAudioInput(QObject* parent = nullptr);
	~AsAudioInput();
	enum ByteOrder {
		BigEndian = QSysInfo::BigEndian, LittleEndian = QSysInfo::LittleEndian
	};
	enum SampleType {
		Unknown, SignedInt, UnSignedInt, Float
	};

private:
	AS_MEMBER_CLASS(AsAudioInput)* mp;

public:
	int sampleRate() const;
	int sampleSize() const;
	int channelCount() const;
	QString codec() const;
	ByteOrder byteOrder() const;
	SampleType sampleType() const;
	int takeRate() const;

public:
	void setSampleRate(int sampleRate);
	void setSampleSize(int sampleSize);
	void setChannelCount(int channelCount);
	void setCodec(const QString codec);
	void setByteOrder(ByteOrder byteOrder);
	void setSampleType(SampleType sampleType);
	void setTakeRate(int takeRate);

public:
	bool startup();
	bool startup(int takeRate);
	bool startup(int index, int takeRate);

public:
	static QList<QString> availableDevices();

signals:
	void sigTakeData(const QVector<float>& datas);

};
