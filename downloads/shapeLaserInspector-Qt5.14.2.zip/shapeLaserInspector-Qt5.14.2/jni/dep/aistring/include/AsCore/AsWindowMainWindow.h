﻿#pragma once
#include "AsWindowBasics.h"
#include "AsDefine.h"
#include <QToolButton>

__AS_JY(2023.1.7)
AS_MEMBER_CLASS_DECLARATION(AsWindowMainWindow);

class AS_CORE_EXPORT AsWindowMainWindow : public QObject, public AsBinder<AsWindowMainWindow> {
	Q_OBJECT

public:
	AsWindowMainWindow(QWidget* window, QWidget* body, QWidget* head);
	~AsWindowMainWindow();

private:
	AS_MEMBER_CLASS(AsWindowMainWindow)* m;

public:
	void setRunning(bool isRunning);

public:
	void bindHead(QAbstractButton* minimized, QAbstractButton* maximized, QAbstractButton* close);
	void bindHead_Minimized(QAbstractButton* button);
	void bindHead_Maximized(QAbstractButton* button);
	void bindHead_Close(QAbstractButton* button);

signals:
	void sigWindowPosChanged(const QPoint& pos);

};

namespace AsWindowNamespace {
	typedef AsWindowMainWindow MainWindow;
}
