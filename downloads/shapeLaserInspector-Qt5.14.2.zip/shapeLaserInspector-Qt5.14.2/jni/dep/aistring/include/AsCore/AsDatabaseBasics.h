﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsDefine.h"
#include <QVariantList>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

namespace As {

	void AS_CORE_EXPORT showDatabase(const QSqlDatabase& database);
};

class AS_CORE_EXPORT AsSqlMaker {
public:
	enum DataAttribute {
		Int = 0x0001,
		Double = 0x0002,
		Varchar256 = 0x0004,
		Varchar = 0x0008,
		Text = 0x0010,
		Date = 0x0020,
		Varbinary = 0x0040,

		PrimaryKey = 0x10000,
		NotNull = 0x20000,
		AutoIncrement = 0x40000,
	};
	static QString strDataAttribute(unsigned __int64 dataAttribute);

public:
	static QString createTable_ifNotExists(const QString& tableName, const QVector<QString>& keys, const QVector<unsigned __int64>& dataAttributes);
	static QString createTable_ifNotExists(const QString& tableName, const QVector<QString>& keys, const QVector<QString>& dataAttributes);
	static QString dropTable(const QString& tableName);

	static QString insert(const QString& tableName, const QVector<QString>& keys, const QVector<QVariant>& values);

	static QString selectAll(const QString& tableName);
	static QString select(const QString& tableName, const QVector<QString>& keys, const QString& conditions);

};
