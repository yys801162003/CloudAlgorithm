#pragma once
#include <QSet>
#include <QByteArray>
#include <QDataStream>
#include "AsSerializableMethod.h"



class AS_CORE_EXPORT AsSerializable
{
	using Pair_Type_DataPtr = std::pair<QString, void*>;
private:
	QSet<Pair_Type_DataPtr>	m_setData;

public:
	AsSerializable();
	~AsSerializable();

	virtual QByteArray serialize();
	virtual void deserialize(const QByteArray& data);

	virtual void toDataStream(QDataStream& inStream) {};
	virtual void fromDataStream(QDataStream& outStream) {};

};


