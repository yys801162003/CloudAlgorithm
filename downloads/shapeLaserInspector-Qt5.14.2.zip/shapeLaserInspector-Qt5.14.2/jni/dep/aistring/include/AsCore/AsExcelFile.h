﻿#pragma once
#pragma warning(disable : 4099)
#include "AsCoreGlobal.h"
#include <QColor>

class QAxObject;

class AS_CORE_EXPORT AsExcelFile {
public:
	class AS_CORE_EXPORT AsStyle {
	public:
		static const int ALIGN_LEFT = -4131;
		static const int ALIGN_RIGHT = -4152;
		static const int ALIGN_CENTER = -4108;
		static const int ALIGN_TOP = -4160;
		static const int ALIGN_BOTTOM = -4107;
		static const int TCOLOR = 0;
		static const int TALIGN = 1;
	private:
		class AsCellStyle {
		public:
			AsCellStyle(int type, int row, int col, int val1, int val2);
			AsCellStyle(int row, int col, QColor color);
		public:
			int type;
			int row;
			int col;
			int val1;
			int val2;
			QColor color;
		};
	private:
		QList<AsCellStyle> csList;
	public:
		void AddCellStype_Color(int row, int col, QColor color);
		void AddCellStype_Align(int row, int col, int hor_align, int ver_align = ALIGN_CENTER);
		int size() const;
		AsCellStyle& operator[](int i);
	};

public:
	AsExcelFile(QString filename, QString sheetname = QString());

private:
	QString filename;
	QString sheetname;
	QAxObject *pApplication;
	QAxObject *pWorkBooks;
	QAxObject *pWorkBook;
	QAxObject *pSheets;
	QAxObject *pSheet;

private:
	void newExcel();
	void appendSheet(const QString &sheetName, int cnt);
	void setCellValue(int row, int column, const QString &value);
	void saveExcel();
	void releaseExcel();

public:
	void save(const QList<QList<QString>>& dataTableOtStyle, AsStyle style = AsStyle());

};

