#pragma once

#include <QObject>
#include "AsCoreGlobal.h"
#include "AsDefine.h"
#include "AsRpcParam.h"


AS_MEMBER_CLASS_DECLARATION(AsRpcClient);

class AS_CORE_EXPORT AsRpcClient  : public QObject
{
	Q_OBJECT

private:
	AS_MEMBER_CLASS(AsRpcClient)* mp;

public:
	explicit AsRpcClient(QObject *parent = nullptr);
	~AsRpcClient();

	// 设置客户端的唯一标识
	void setClientId(const QString& clientId);

	// 设置异常重连
	void setErrorReLinker(bool enable = true);

	// 设置服务Host地址
	void setServerHost(const QString& serverIp,const quint16& serverPort);

	// 回传数据
	void callbackData(const QString& dllId, const QString& method, const AsRpcParam& results);

	// 获取参数
	bool takeRequest(QString& dllId,QString& method,AsRpcParam& request);

	// 连接服务
	void linkServer();

	// 断开服务器
	void breakupServer();

	
signals:
	void sigRecvRequest();
	
};
