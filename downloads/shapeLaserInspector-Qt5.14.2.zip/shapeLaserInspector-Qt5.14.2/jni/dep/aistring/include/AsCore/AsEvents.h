﻿#pragma once
#include "AsEventBasics.h"

__AS_JY(2023.1.7)
class AS_CORE_EXPORT AsEvents : public QObject {
public:
	explicit AsEvents(QObject* parent = nullptr);
	~AsEvents();

private:
	AS_MEMBER_CLASS(AsEvents)* m;

public:
	bool	isPressed(AE::Key::Enum key);
	bool	isReleased(AE::Key::Enum key);

	bool	isMovePressedMouse();
	bool	isPress_MouseLeft();
	bool	isPress_MouseRight();
	bool	isPress_Ctrl();
	bool	isPress_Shift();
	bool	isPress_Alt();
	bool	isDoubleClicked_MouseLeft();
	bool	isDoubleClicked_MouseRight();

	int		getPressMouseButton();
	int		getDoubleClickedMouseButton();
	int		getReleaseMouseButton();
	int		getPressKey();
	int		getReleaseKey();

	QPointF	getMousePos(AE::CoordSystem::Enum type = AE::CoordSystem::Widget);
	QPointF	getMousePressPos(AE::CoordSystem::Enum type = AE::CoordSystem::Widget);
	QPointF	getMouseReleasePos(AE::CoordSystem::Enum type = AE::CoordSystem::Widget);
	QPointF	getMouseMoveDistance(AE::CoordSystem::Enum type = AE::CoordSystem::Widget);
	QPointF	getMousePressMoveDistance(AE::CoordSystem::Enum type = AE::CoordSystem::Widget);
	QRectF	getMousePressMoveRect(AE::CoordSystem::Enum type = AE::CoordSystem::Widget, QPointF offset = QPoint(0, 0));

	QPointF	getMousePos_keyPress(AE::CoordSystem::Enum type = AE::CoordSystem::Widget);
	QPointF	getMousePos_keyRelease(AE::CoordSystem::Enum type = AE::CoordSystem::Widget);

	int		getWheelDistance();

private:
	friend class AsEventSink;

};

