﻿#pragma once
#include "AsCoreGlobal.h"
#include <QImage>
#include <QSharedPointer>

class ImageSaveServicePrivate;
class AS_CORE_EXPORT AsImageSaveService {
public:
	AsImageSaveService();
	~AsImageSaveService();

private:
	ImageSaveServicePrivate* m_pPrivate;

private:
	static QSharedPointer<AsImageSaveService> ms_spInstance;

public:
	static QSharedPointer<AsImageSaveService> getInstance();

public:
	void saveImage(QString filepath, QImage image);
	void saveMat(QString filepath, cv::Mat image);
	void asyncSaveImage(QString filepath, QImage image);
	void asyncSaveMat(QString filepath, cv::Mat image);

};

namespace As {

	extern AS_CORE_EXPORT void saveImage(QString filePath, QImage image);
	extern AS_CORE_EXPORT void asyncSaveImage(QString filePath, QImage image);
	extern AS_CORE_EXPORT void saveMat(QString filePath, cv::Mat image);
	extern AS_CORE_EXPORT void asyncSaveMat(QString filePath, cv::Mat image);
}


