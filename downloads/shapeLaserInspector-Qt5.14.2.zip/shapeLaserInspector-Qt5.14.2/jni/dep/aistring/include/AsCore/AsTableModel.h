﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsTableModelRow.h"
#include <QAbstractTableModel>

class AS_CORE_EXPORT AsTableModel : public QAbstractTableModel {
public:
	AsTableModel();
	~AsTableModel();

private:
	QVector<AsTableModelRow*>	m_vpRows;
	AsTableModelRow*			m_pTitleRow;

public:
	int rowCount(const QModelIndex& parent) const override;
	int columnCount(const QModelIndex& parent) const override;
	QVariant data(const QModelIndex& index, int role) const override;
	QVariant headerData(int section, Qt::Orientation orientation, int role) const override;

	void clearRows();
	void addRow(AsTableModelRow* pRow);
	void addRows(const QVector<AsTableModelRow*>& vpRow);
	void setTitleRow(AsTableModelRow* pRow);
	AsTableModelRow* getItem(int row);
	void refreshData();

private:
	void releaseRows();
	void releaseTitleRow();
	QString formatResult(int iResult)const;

};

