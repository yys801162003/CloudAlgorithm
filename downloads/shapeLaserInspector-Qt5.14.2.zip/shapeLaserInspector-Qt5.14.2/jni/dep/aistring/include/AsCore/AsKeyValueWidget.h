﻿#pragma once
#include "AsCoreGlobal.h"

#include <QWidget>
#include <QLabel>
#include <QMap>
#include <QGridLayout>
#include <QVariant>

class ASCORE_EXPORT AsKeyValueWidget :public QWidget
{
private:
	QMap<QString, QLabel*>					m_labelMap;			//数据表
	QGridLayout*							m_pLayout;			//布局器
	int										m_iLabelWidth;		//标头宽度

public:
	AsKeyValueWidget(QWidget* parent = nullptr);

	void registerKey(QString label, QString key, QString defaultValue = "");
	void setValue(QString key, QString value);
	void setLabelProperty(QString labelKey, QString propertyKey, QVariant value);
	void setLabelWidth(int width);

private:
	void init();

};

