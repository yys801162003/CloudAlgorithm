﻿#pragma once
#include "AsCoreGlobal.h"
#include "AsBinder.hpp"
#include "AsDefine.h"
#include "AsTreeWidget.h"

AS_MEMBER_CLASS_DECLARATION(AsTreeController);

class AS_CORE_EXPORT AsTreeController : public AsBinder<AsTreeWidget> {

public:
	explicit AsTreeController(AsTreeWidget* core = nullptr);
	AsTreeController(const AsTreeController& con);
	~AsTreeController();

private:
	AS_MEMBER_CLASS(AsTreeController)* m;

public:
	AsTreeWidget* core();
	void setCore(AsTreeWidget* core);

public:
	void setHeader(const QVector<QString>& names);

public:
	QTreeWidgetItem* topItem(int index = 0);

public:
	void resizeColumnToContents();
	void expandAll();

public:
	QTreeWidgetItem*			addTop(const QVector<QVariant>& contents, bool expand = true);
	QVector<QTreeWidgetItem*>	addTops(const QVector<QVariant>& contents, bool expand = true);
	QVector<QTreeWidgetItem*>	addTops(const QVector<QVector<QVariant>>& contents, bool expand = true);
	QTreeWidgetItem*			addChild(QTreeWidgetItem* parent, const QVector<QVariant>& contents, bool expand = true);
	QVector<QTreeWidgetItem*>	addChildren(QTreeWidgetItem* parent, const QVector<QVariant>& contents, bool expand = true);
	QVector<QTreeWidgetItem*>	addChildren(QTreeWidgetItem* parent, const QVector<QVector<QVariant>>& contents, bool expand = true);
	void setItemText(QVector<QTreeWidgetItem*> items, const QVariant& text, int column = 0);

public:
	int indexOfItem(QTreeWidgetItem* item);

public:
	inline void setHeader(const QString& name) { setHeader(QVector<QString>(1, name)); }
	inline QTreeWidgetItem* addTop(const QVariant& content) { return addTop(QVector<QVariant>(1, content)); };
	inline QTreeWidgetItem* addChild(QTreeWidgetItem* parent, const QVariant& content) { return addChild(parent, QVector<QVariant>(1, content)); }
	inline void setItemText(QTreeWidgetItem* item, const QVariant& text, int column = 0) { setItemText(QVector<QTreeWidgetItem*>(1, item), text, column); };

};

