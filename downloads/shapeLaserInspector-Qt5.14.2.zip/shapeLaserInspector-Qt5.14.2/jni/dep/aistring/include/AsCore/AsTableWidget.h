﻿#pragma once
#include "AsCoreGlobal.h"
#include <QTableWidget>

class AS_CORE_EXPORT AsTableWidget : public QTableWidget {
	Q_OBJECT

public:
	friend class AsTableController;
	explicit AsTableWidget(QWidget *parent);

private:
	void showEvent(QShowEvent* e) override;
	void resizeEvent(QResizeEvent* e) override;
	void dragEnterEvent(QDragEnterEvent* e) override;
	void dragMoveEvent(QDragMoveEvent* e) override;
	void dragLeaveEvent(QDragLeaveEvent* e) override;
	void dropEvent(QDropEvent* e) override;

signals:
	void sigShow(QShowEvent* e);
	void sigResize(QResizeEvent* e);
	void sigUpdate();
	void sigCellActivated(int row, int column);
	void sigCellEntered(int row, int column);
	void sigCellChanged(int row, int column);
	void sigCellPressed(int row, int column);
	void sigCellClicked(int row, int column);
	void sigCellDoubleClicked(int row, int column);
	void sigCurrentCellChanged(int currentRow, int currentColumn, int previousRow, int previousColumn);
	void sigCurrentItemChanged(QTableWidgetItem* current, QTableWidgetItem* previous);
	void sigItemActivated(QTableWidgetItem* item);
	void sigItemEntered(QTableWidgetItem* item);
	void sigItemChanged(QTableWidgetItem* item);
	void sigItemPressed(QTableWidgetItem* item);
	void sigItemClicked(QTableWidgetItem* item);
	void sigItemDoubleClicked(QTableWidgetItem* item);
	void sigItemSelectionChanged();
	void sigFileDragIn(QString filename);

private:
	void initSignals();

};