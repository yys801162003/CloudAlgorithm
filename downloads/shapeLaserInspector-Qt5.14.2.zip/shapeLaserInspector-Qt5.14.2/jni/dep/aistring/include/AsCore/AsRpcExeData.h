#pragma once
#include <AsJsonObject.h>
#include "AsCoreGlobal.h"

class AS_CORE_EXPORT AsRpcExeData :public AsJsonObject
{
public:
	AsRpcExeData();
	~AsRpcExeData();
	virtual void onBuildStructure()const;

	// 序列化exe信息
	QByteArray serializeClientData();

	// 反序列化exe信息
	void deserializeClientData(const QByteArray& byteArray);

public:
	QString serverIp;		// 服务器Ip
	quint16	serverPort;		// 服务器端口
	QString clientId;		// 客户端唯一标识
	int clientState;		// 客户端状态
	bool isWithWindows;		// 客户端是否显示窗口
};

