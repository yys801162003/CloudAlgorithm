#pragma once
#include "AsCoreGlobal.h"
template <typename _Type>
class AsToolContainerIndex {
public:
	AsToolContainerIndex(const _Type& container) {
		this->container = &container;
		currentIndex = 0;
	}

private:
	const _Type* container;
	int currentIndex;

public:
	bool isValid() {
		return currentIndex >= 0 && currentIndex < container->size();
	}
	bool toBegin(int offset = 0) {
		currentIndex = 0 + offset;
		return isValid();
	}
	bool toEnd(int offset = 0) {
		currentIndex = container->size() - 1 + offset;
		return isValid();
	}
	bool toNext(int step = 1) {
		currentIndex += step;
		return isValid();
	}
	bool toLast(int step = 1) {
		currentIndex -= step;
		return isValid();
	}
	int current() {
		return currentIndex;
	}

};

