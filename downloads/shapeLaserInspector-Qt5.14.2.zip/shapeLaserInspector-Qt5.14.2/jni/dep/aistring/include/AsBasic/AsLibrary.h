﻿#pragma once
#include "AsBasicGlobal.h"
#include "AsDefine.h"

typedef void(*AsFunctionPointer)();

__AS_JY(Update 2023.1.7)
class AS_BASIC_EXPORT AsLibrary {
public:
	enum Flag { AutoFree, NotFree };

public:
	AsLibrary();
	AsLibrary(const std::string& filename, Flag flag = Flag::NotFree);
	~AsLibrary();

private:
	Flag mFlag;
	std::string mFilename;

public:
	void load(const std::string& filename, Flag flag = Flag::NotFree);
	void free();
	AsFunctionPointer resolve(const std::string& funcname);

public:
	static AsFunctionPointer resolve(const std::string& dllFilename, const std::string& funcname);

};
