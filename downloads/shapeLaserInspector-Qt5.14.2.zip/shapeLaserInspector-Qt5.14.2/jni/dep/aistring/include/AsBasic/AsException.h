﻿#pragma once
#include "AsBasicGlobal.h"
#include "AsDefine.h"

__AS_JY(Update 2022)
class AS_BASIC_EXPORT AsException {
public:
	enum ExceptionCode {
		CodeUnknown,
		CodeVectorMap_IndexOutOfRange,
		CodeMap_NotFindKey,
		CodeOptions_IndexOutOfRange,
		CodeVariant_Empty,
		CodeVariant_ErrorType,
		CodeVariant_InconsistencyType,
		CodeEnvironment_NoInstance,
		CodeEnvironment_SetupFailed,
		CodeEnvironment_SaveFailed,
		CodeEnvironment_GetFailed,
		CodeEnvironment_NoGuiSpecified,
		CodeMethod_ValueMapConvert,
		Code_IndexOutOfRange,
		Code_NotFindKey,
		CodeAmount
	};

public:
	AsException();
	AsException(const std::string& info);
	AsException(ExceptionCode code);
	AsException(ExceptionCode code, const std::string& info);

protected:
	int mCode;
	std::string mInfo;

public:
	int getCode();
	std::string strInfo();
	std::string strException();

public:
	static void Throw(ExceptionCode code, const std::string& info);

};


