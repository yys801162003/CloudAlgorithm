﻿#pragma once
#include "AsContainerBasics.h"
#include "AsBinaryFile.h"
#include "AsTextStream.h"

__AS_JY(Update 2023.1.16)
namespace As {
	
	AS_MEMBER_CLASS_DECLARATION(CustomData);

	// 自定义数据
	class AS_BASIC_EXPORT CustomData {
	public:
		CustomData();
		CustomData(const CustomData& data);
		virtual ~CustomData();
		CustomData& operator=(const CustomData& data);

	private:
		AS_MEMBER_CLASS(CustomData)* mp;

	private:
		void updateData() const;
		void updateMember();
		void write(AsBinaryFile& bstm) const;
		void read(AsBinaryFile& bstm);

	protected:
		virtual void toText(AsTextStream& out) ;
		virtual void fromText(AsTextStream& in);

	public:
		std::string str() const;
		void fromstr(std::string str);
		void from(const AsCustomData& cd);

	public:
		friend AsBinaryFile& operator<<(AsBinaryFile& f, const AsCustomData& data);
		friend AsBinaryFile& operator>>(AsBinaryFile& f, AsCustomData& data);
		friend AsTextStream& operator<<(AsTextStream& s, const AsCustomData& data);
		friend AsTextStream& operator>>(AsTextStream& s, AsCustomData& data);

	};

	AsBinaryFile& operator<<(AsBinaryFile& f, const AsCustomData& data);
	AsBinaryFile& operator>>(AsBinaryFile& f, AsCustomData& data);
	AsTextStream& operator<<(AsTextStream& s, const AsCustomData& data);
	AsTextStream& operator>>(AsTextStream& s, AsCustomData& data);
	
};
