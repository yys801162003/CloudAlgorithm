﻿#pragma once
#include "AsVariant.h"
#include "AsSharedObject.hpp"

// super container

__AS_JY(Update 2023.1.7)
namespace As {

	class AS_BASIC_EXPORT Container : public AS_SHARED_OBJECT(Container) {
	public:
		Container();

	public:
		int			size()								const;
		int			property(const std::string& name)	const;
		bool		contains(const std::string& name)	const;
		std::string tostr(bool hasAddress = false)		const;

		bool		isConst(const std::string& name)	const;
		bool		isStorage(const std::string& name)	const;
		bool		isEternity(const std::string& name) const;

	public:
		enum Property {
			Error = -1,
			None = 0x00,
			Const = 0x01,
			Storage = 0x02,
			Eternity = 0x04,
			StorageConst = Const | Storage
		};
 

	public:
		void defVariant(const std::string& name, const Variant& variant, uint64_t property = Storage);
		bool addVariant(const std::string& name, const Variant& variant, uint64_t property = Storage);
		bool addVariant(uint64_t property, const Variant& variant);
		bool addVariant(const Variant& variant);
		void setVariant(const std::string& name, const Variant& variant);
		void setVariant(const std::string& name, const Variant& variant, uint64_t property);

		Variant&		getVariant(const std::string& name)					;
		const Variant&	getVariant(const std::string& name)			const	;
		const Variant&	getConstVariant(const std::string& name)	const	;

		inline bool				addConst(const std::string& name, const Variant& variant) { return addVariant(name, variant, StorageConst); }
		inline void				setConst(const std::string& name, const Variant& variant) { setVariant(name, variant, StorageConst); }
		inline const Variant&	getConst(const std::string& name)					const { return getConstVariant(name); }

		bool removeVariant(const std::string& name);
		void clearVariants();

		bool setProperty(const std::string& name, int property);

		void enableConst(const std::string& name);
		void enableStorage(const std::string& name);
		void enableEternity(const std::string& name);

		void disableConst(const std::string& name);
		void disableStorage(const std::string& name);
		void disableEternity(const std::string& name);

	public:
		std::vector<std::string>						allNames()		const;
		std::vector<Variant>							allVariants()	const;
		std::vector<std::pair<std::string, Variant>>	allPairs()		const;

	public:
		enum AccessOptions {
			NormalAccess	= 0x01,
			CompressAccess	= 0x02,
			AutoAccess		= 0x04
		};
		bool load(const std::string& filepath = "unnamed.aconta", unsigned __int64 options = AutoAccess);
		bool save(const std::string& filepath = "unnamed.aconta", unsigned __int64 options = AutoAccess) const;

	};

};
typedef As::Container AsContainer;

