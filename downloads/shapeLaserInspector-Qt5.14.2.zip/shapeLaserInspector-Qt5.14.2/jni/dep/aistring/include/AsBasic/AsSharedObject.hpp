﻿#pragma once
#include <memory>
#define AS_SHARED_OBJECT(SUBCLASS) AsSharedObject<SUBCLASS, AS_MEMBER_CLASS(SUBCLASS)>
#define AS_SHARED_OBJECT_INIT AsSharedObject::initMp(mp.get())

template <typename _ObjectType, typename _ObjectMembersType>
class AsSharedObject {
public:
	AsSharedObject() {
		
	}
	virtual ~AsSharedObject() {
		mp = nullptr;
	}

protected:
	std::shared_ptr<_ObjectMembersType> mp;

protected:
	template <typename _ObjectMembersType>
	void initMp(_ObjectMembersType* temp) {
		this->mp = std::shared_ptr<_ObjectMembersType>(new _ObjectMembersType());
	}

};

