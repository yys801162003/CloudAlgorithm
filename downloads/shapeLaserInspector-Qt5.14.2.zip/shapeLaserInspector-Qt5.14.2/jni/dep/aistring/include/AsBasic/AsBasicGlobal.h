#pragma once
#pragma warning(disable : 4099)
#pragma warning(disable : 4244)
#pragma warning(disable : 4251)
#pragma warning(disable : 4267)

#ifndef BUILD_STATIC
# if defined(ASBASIC_LIB)
#  define AS_BASIC_EXPORT __declspec(dllexport)
# else
#  define AS_BASIC_EXPORT __declspec(dllimport)
# endif
#else
# define AS_BASIC_EXPORT
#endif

#ifdef _WIN32
#define AS_DLL_EXPORT __declspec(dllexport)
#else
#define AS_DLL_EXPORT
#endif

#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <opencv2\core.hpp>

#define __AS_WJ(...)
#define __AS_ZW(...)
#define __AS_JY(...)
#define __AS_SYK(...)
