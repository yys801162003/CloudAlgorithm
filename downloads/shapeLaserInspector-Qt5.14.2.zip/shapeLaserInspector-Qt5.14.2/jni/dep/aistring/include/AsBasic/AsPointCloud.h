﻿#pragma once
#include "AsBasicGlobal.h"
#include "AsDefine.h"
#include <string>
#include <vector>

__AS_JY(Update 2022)
class AS_BASIC_EXPORT AsPointCloud {
public:
	enum SaveOption {
		Normal = 0x00,
		LZ4Compress = 0x01,
		OldVersion20230505 = 0x10000000
	};

public:
	AsPointCloud();
	AsPointCloud(int width, int length);
	AsPointCloud(int width, int length, cv::Point3f point);
	AsPointCloud(const std::string& filename);

private:
	std::string m_filename;
	std::shared_ptr<std::vector<cv::Point3f>> m_points;
	int m_width;
	int m_length;
	uint64_t m_saveOptions;

protected:
	virtual void write(std::ofstream& f) const;
	virtual void read(std::ifstream& f);

public:
	bool load_before20230505(const std::string& filename = std::string());
	// 加载点云文件
	bool load(const std::string& filename = std::string());
	// 保存点云文件
	bool save(const std::string& filename, uint64_t saveOptions);
	bool save(const std::string& filename = std::string());
	bool save(uint64_t saveOptions);

public:
	int _version() const;
	std::string tostr() const;

public:
	// 判断点云是否为空
	bool isNull() const;
	// 获取开头指针
	cv::Point3f* pbegin() const;
	// 获取行开头指针
	cv::Point3f* pbegin(int row) const;
	// 获取结尾指针
	cv::Point3f* pend() const;
	// 获取行结尾指针
	cv::Point3f* pend(int row) const;
	// 获取迭代器开头
	std::vector<cv::Point3f>::iterator begin();
	// 获取常迭代器开头
	std::vector<cv::Point3f>::const_iterator cbegin() const;
	// 获取迭代器结尾
	std::vector<cv::Point3f>::iterator end();
	// 获取常迭代器结尾
	std::vector<cv::Point3f>::const_iterator cend() const;
	// 获取点云宽度
	int width() const;
	// 获取点云长度
	int length() const;
	// 获取数据大小
	int size() const;
	// 获取点云毫米长度
	float length_mm();
	// 重置点云大小
	void resize(int width, int length);
	// 清空点云
	void clear();

public:
	void setSaveOptions(uint64_t saveOptions);

};
