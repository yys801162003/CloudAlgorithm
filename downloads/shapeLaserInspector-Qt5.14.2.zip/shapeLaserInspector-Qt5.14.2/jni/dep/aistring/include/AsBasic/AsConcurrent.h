﻿#pragma once
#include "AsDefine.h"

AS_MEMBER_CLASS_DECLARATION(AsConcurrent);

class AS_BASIC_EXPORT AsConcurrent {
public:
	AsConcurrent();
	~AsConcurrent();

private:
	AS_MEMBER_CLASS(AsConcurrent)* mp;

private:
	void add(std::thread* thread);

public:
	void wait();

public:
	template <typename _Lambda>
	void begin(_Lambda lambda) {
		add(new std::thread(lambda));
	}

};
