﻿#pragma once
#include "AsContainerBasics.h"

AS_MEMBER_CLASS_DECLARATION(AsBinaryStream);

class AS_BASIC_EXPORT AsBinaryStream {
public:
	AsBinaryStream();
	AsBinaryStream(const std::string& str);
	~AsBinaryStream();

private:
	AS_MEMBER_CLASS(AsBinaryStream)* mp;

public:
	int length() const;
	const char* data() const;

public:
	void write(const char* ptr, size_t size);
	void read(char* ptr, size_t size);

public:
	template <typename _Type>
	AsBinaryStream& operator<<(const _Type& data) {
		write((const char*)&data, sizeof(data));
		return *this;
	}
	template <typename _Type>
	AsBinaryStream& operator>>(_Type& data) {
		read((char*)&data, sizeof(data));
		return *this;
	}
	AsBinaryStream& operator<<(const std::string& data);
	AsBinaryStream& operator>>(std::string& data);
	template <typename _Type>
	AsBinaryStream& operator<<(const std::vector<_Type>& datas) {
		*this << datas.size();
		for (const auto& data : datas) *this << data;
		return *this;
	}
	template <typename _Type>
	AsBinaryStream& operator>>(std::vector<_Type>& datas) {
		size_t size = 0;
		*this >> size;
		datas.resize(size);
		for (auto& data : datas) *this >> data;
		return *this;
	}
	AsBinaryStream& operator<<(const cv::Mat& mat);
	AsBinaryStream& operator>>(cv::Mat& mat);

};

