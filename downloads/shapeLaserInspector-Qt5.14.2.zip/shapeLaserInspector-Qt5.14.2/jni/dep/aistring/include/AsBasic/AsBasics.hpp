﻿#pragma once

namespace As {

	template <typename _Container, typename _Functor>
	void _foreach(_Container& cont, _Functor& action) {
		for (class _Container::iterator it = cont.begin(); it != cont.end(); it++) {
			if (action(*it)) return;
		}
	}

	template <typename _Container, typename _Functor>
	void cforeach(const _Container& cont, _Functor& action) {
		for (class _Container::const_iterator it = cont.cbegin(); it != cont.cend(); it++) {
			if (action(*it)) return;
		}
	}
	
	template <typename _Container, typename _Functor>
	void _foreach(_Container& cont, const _Functor& action) {
		for (class _Container::iterator it = cont.begin(); it != cont.end(); it++) {
			if (action(*it)) return;
		}
	}

	template <typename _Container, typename _Functor>
	void cforeach(const _Container& cont, const _Functor& action) {
		for (class _Container::const_iterator it = cont.cbegin(); it != cont.cend(); it++) {
			if (action(*it)) return;
		}
	}

	template <typename _Type>
	void reverseByteOrder(_Type& data) {
		char* p = reinterpret_cast<char*>(&data);
		for (int i = 0, j = sizeof(data) - 1; i < j; i++, j--) {
			p[i] ^= p[j];
			p[j] ^= p[i];
			p[i] ^= p[j];
		}
	}

};

