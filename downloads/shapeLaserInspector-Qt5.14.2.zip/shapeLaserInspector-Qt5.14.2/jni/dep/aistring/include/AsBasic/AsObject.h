﻿#pragma once
#include "AsContainerBasics.h"
#include "AsVariant.h"
#define asDef(__var__) def(__var__, #__var__)

namespace AsPrivate { class Object; };

__AS_JY(Update 2023.1.16)
namespace As {

	class AS_BASIC_EXPORT Object {
	public:
		Object();
		Object(const Object& object);
		virtual ~Object();
		Object& operator=(const Object& object);

	private:
		AsPrivate::Object* mp;

	private:
		void update_construct(int flag);
		void write(AsBinaryFile& f) const;
		void read(AsBinaryFile& f);

	protected:
		virtual void construct();

	public:
		int count() const;
		void from(const Object& object);
		String tostr() const;
		Variant& operator[](int i);
		Variant& operator[](String name);
		const Variant& operator[](int i) const;
		const Variant& operator[](String name) const;
		StringArray allNames() const;

	protected:
		void define(Pointer addr, const Variant& var);
		void define(Pointer addr, const Variant& var, String name);
		template <typename _Type>
		void def(_Type& var) { define((Pointer)&var, var); }
		template <typename _Type>
		void def(_Type& var, String name) { define((Pointer)&var, var, name); }

	protected:
		static char _;
		friend class Variant;
		friend class AS_MEMBER_CLASS(Variant);
		friend AsBinaryFile& operator<<(AsBinaryFile& f, AsObject& object);
		friend AsBinaryFile& operator>>(AsBinaryFile& f, AsObject& object);
		
	};

	AsBinaryFile& operator<<(AsBinaryFile& f, AsObject& object);
	AsBinaryFile& operator>>(AsBinaryFile& f, AsObject& object);

}; 

