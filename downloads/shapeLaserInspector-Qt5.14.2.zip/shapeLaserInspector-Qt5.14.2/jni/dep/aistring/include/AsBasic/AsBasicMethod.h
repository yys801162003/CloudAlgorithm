﻿#pragma once
#include "AsBasicGlobal.h"
#include "AsDefine.h"
#include "AsBasics.hpp"
#include "AsDebug.h"

__AS_JY(Update 2023.1.7)
namespace As {

	AS_BASIC_EXPORT std::string dec2Hex(const std::string& str);
	AS_BASIC_EXPORT std::string dec2Hex(uint64_t dec);
	AS_BASIC_EXPORT std::string hex2Dec(const std::string& str);
	AS_BASIC_EXPORT std::string hex2Dec(uint64_t hex);

	AS_BASIC_EXPORT void writeString(std::ofstream& f, const std::string& str);
	AS_BASIC_EXPORT void readString(std::ifstream& f, std::string& str);

	AS_BASIC_EXPORT std::string strMatType(int type);

	AS_BASIC_EXPORT bool isAbsolutePath(const std::string& path);
	AS_BASIC_EXPORT bool hasSuffix(const std::string& path);
	AS_BASIC_EXPORT std::string desuffix(const std::string& path);

	AS_BASIC_EXPORT std::string toAbsolutePath(const std::string& location, const std::string& filename);

	template<typename _CHILDTYPE, typename _TYPE>
	_TYPE* constructChild() {
		if (std::is_base_of<_TYPE, _CHILDTYPE>()) {
			return new _CHILDTYPE;
		}
		else {
			AsDebug() << typeid(_CHILDTYPE).name() << "不是" << typeid(_TYPE).name() << "的子类";
			return nullptr;
		}
	}
};

namespace As {

	// 读 Apc 文件
	AS_BASIC_EXPORT bool LoadApc(std::string filepath, std::vector<float>& values, int& width, int& height);
	// 写 Apc 文件
	AS_BASIC_EXPORT bool SaveApc(std::string filepath, const std::vector<float>& values, int width, int height);

};