﻿#pragma once
#include "AsBasicGlobal.h"
#include <memory>

class AsSystemPrivate;

class AS_BASIC_EXPORT AsSystem {
private:
	AsSystem();

private:
	static std::unique_ptr<AsSystemPrivate> smp;

public:
	static const wchar_t* towchars(const char* c_str);
	static const wchar_t* towchars(std::string str);
	static const char* tochars(const wchar_t* w_str);
	static std::string unicode2gbk(const char* c_str_unicode);
	static std::string gbk2unicode(const char* c_str_gbk);

public:
	static bool open(std::string path);
	static bool open(std::string path, std::string params);

public:
	static std::string strAppPath();
	static std::string strAppLocationPath();

public:
	static void addDllDirectory(const std::string& directory);
	static void removeDllDirectory(const std::string& directory);

};

