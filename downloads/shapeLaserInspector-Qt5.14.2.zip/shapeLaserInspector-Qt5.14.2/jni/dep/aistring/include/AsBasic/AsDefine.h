#pragma once
#include "AsBasicGlobal.h"

#define AS_DEBUG_OUTPUT_HI(__head__, __info__) qDebug() << "[" << __head__ << "]" << __info__;
#define AS_MEMBER_CLASS(__class__) __##__class__##MemberClass
#define AS_MEMBER_CLASS_DECLARATION(__class__) struct AS_MEMBER_CLASS(__class__)
#define AS_MEMBER_CLASS_DEFINE(__class__) struct AS_MEMBER_CLASS(__class__)
#define AS_PRIVATE_CLASS(__class__) __##__class__##PrivateClass
#define AS_PRIVATE_CLASS_DECLARATION(__class__) struct AS_PRIVATE_CLASS(__class__)
#define AS_INTERNAL

typedef char				aint8s;
typedef short				aint16s;
typedef int					aint32s;
typedef long long			aint64s;
typedef unsigned char		aint8u;
typedef unsigned short		aint16u;
typedef unsigned int		aint32u;
typedef unsigned long long	aint64u;
typedef float				af32;
typedef double				af64;

using AsVoidFunc = std::function<void()>;


namespace AsDefine {

	enum AsErrorCode {
		AsError_Unknown = -1,

		AsError_NoError = 0,					//无错误

		AsError_FileNotFound = 51,				//文件未找到

		AsError_LibLoadFail = 61,				//库文件加载失败
		AsError_FunctionNotFound,				//函数未找到
		AsError_InstanceFunctionNotFound,		//实例化函数未找到
		AsError_RegisterNotFound,				//注册机未找到
		AsError_FunctionCallException,			//函数调用异常

		AsError_PreTaskTimeout = 101,			//前置任务超时
		AsError_NoDetectData,					//无检测数据
		AsError_CommuniWaitTimeout,				//通讯等待超时
		AsError_TaskCancelled,					//任务取消

		AsError_TestPluginNotLoad = 201,		//未找到测试插件
		AsError_TestDetectorCtorNotFound,		//未找到检测算子构造器
		AsError_TestResultCtorNotFound,			//未找到结果构造器
		AsError_TestUiCtorNotFound,				//未找到Ui构造器
		AsError_InputIsEmpty,					//输入图像为空

		AsError_AsOptions,
		AsError_AsMethod_GetMinMaxLocal,
		AsError_AsMethod_ValueMapConvert,
		AsError_AsPointCloud,

		AsError_VariantNullptr,
		AsError_VariantErrorType,
	};

	enum {
		Dimension2D = 2,
		Dimension3D = 3
	};

	//全局对象键名
	enum AsGlobalDataRole{
		AsCoreDataRole ,						//核心业务数据
		AsProcessCoreRole = AsCoreDataRole,		//核心业务数据(已废弃)
		AsConfigRole,							//配置类
		AsRoamingDataRole,						//运行时数据
		AsSharedMemoryPoolRole,					//共享内存池类
		AsLocalRpcServerRole,					//本地RPC类
		AsAppInfoRole,							//App版本信息

		/**工具类**/
		AsFileToolRole = 100,			//文件解析类
		AsSqlToolRole,					//文件解析类

		AsUserDataRole = 1000,			//用户自定义键，自定义键请在本键后定义
	};

	//任务状态
	enum AsTaskStatus {
		AsNotStart,				//未开始
		AsProcessing,			//进行中
		AsFinished,				//已完成
	};

	//表格统计字段名称
	enum AsTableRowResult {
		AsResultException=-1,			//异常
		AsResultOK,					//ok			
		AsResultNG,					//ng
		AsResultUserDefine,			//用户自定义
	};

	//数据库类型
	enum AsDbType {
		AsDbSqlite,
		AsDbMySql,
	};

	// AsRpc调用模式
	enum AsRpcType
	{
		eLocal,			// 本地模式
		eRemote			// 远程模式
	};
};

namespace AsRpc {
	const char DETACH_SHAREDMEMORY[] = "detachClientSharedMemory";
}

//All const variables
namespace AsConst {
	const char CONFIG_FOLDER_NAME[] = "config";

	//UI界面中代码样式的键名
	const char PROP_KEY_UI_STYLE[] = "astyle";
	const char PROP_KEY_UI_STATE[] = "astate";
}

const double ZERO_VALUE = 0.000001f;				//0值
const double SMALL_VALUE = -100000.f;				//小值
const double BIG_VALUE = 100000.f;					//大值

