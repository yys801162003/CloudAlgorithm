﻿#pragma once
#include "AsTask.h"
#include "AsDefine.h"

// 单动任务类
template<typename T>
class AsActionTask : public AsTask 
{
	typedef void (T::*ActionFn)();

private:
	T*			m_pUser;
	ActionFn	m_pFn;

public:
	AsActionTask(T* pUser, ActionFn fn)
		:m_pUser(pUser),
		m_pFn(fn) {
		m_qsType = "直接触发";
	}

public:
	virtual int onTaskAction() override {
		(m_pUser->*m_pFn)();
		return AsDefine::AsError_NoError;
	}

};

// 函数任务类(直接执行一个简单函数)
class AsFuncTask :public AsTask
{
private:
	AsVoidFunc m_pFn;

public:
	AsFuncTask(AsVoidFunc fn);

public:
	virtual int onTaskAction() override;

};

// 异步函数任务类(异步执行一个简单函数)
class AsAsyncFuncTask :public AsTask
{
private:
	AsVoidFunc m_pFn;

public:
	AsAsyncFuncTask(AsVoidFunc fn);

public:
	virtual int onTaskAction() override;

};