﻿#pragma once
#include "ADFGlobal.h"
#include <QMutex>

class ADF_EXPORT AsCamera {
public:
	AsCamera();
	virtual ~AsCamera();

private:
	bool m_isInited;				//初始化状态
	QVector<cv::Mat> m_vMat;
	bool m_newDataReady;			//新数据可用状态
	QMutex m_lock;					//锁对象

protected:
	bool isReady();			//
	bool isInit();

	virtual bool onInit() = 0;							//相机初始化,用户实现
	virtual void onUninit() = 0;						//反初始化，用户实现
	virtual void onClearSDKBuffer() {}					//清空相机SDK中的缓存数据
	virtual void onTriggerCamera() {}					//实现相机触发，用户实现，非软件触发时不用实现此函数
	virtual QVector<cv::Mat> onWaitForLatestMats(int waitTime = 10000);	//等待最新的Mat，用户实现，不实现时,默认取一次最新的数据

public:
	bool initCamera();								//初始化相机
	void uninitCamera();							//反初始化相机
	void triggerCamera();							//触发相机一次
	void clearCamera();								//清空相机数据
	void updateMat(const cv::Mat& mat);				//更新图像,会将取图标记置为ok,多图更新请用下面的函数
	void updateMats(const QVector<cv::Mat>& mat);	//更新图像,会将取图标记置为ok。3D数据默认先深度，再灰度
	QVector<cv::Mat> waitForLatestMats(int waitTime = 10000);	//获取所有最新的Mat数据
	cv::Mat waitForLatestMat(int waitTime = 10000);				//获取最新的Mat数据
};

