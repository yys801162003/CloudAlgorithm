﻿#ifndef ASCOMMUNICATOR_H_
#define ASCOMMUNICATOR_H_
#include "ADFGlobal.h"

class ADF_EXPORT AsCommunicator : public QObject {
	Q_OBJECT

public:
	AsCommunicator(QObject* parent = nullptr);
	~AsCommunicator();

	virtual void sendCommand(QString cmd);			//发送指令

signals:
	void commandReceived(int cmd);					//指令接受信号

};

#endif
