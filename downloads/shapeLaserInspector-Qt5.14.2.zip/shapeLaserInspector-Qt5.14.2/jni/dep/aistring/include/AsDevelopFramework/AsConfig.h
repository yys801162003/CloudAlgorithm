﻿#pragma once
#include "ADFGlobal.h"
#include "AsJsonObject.h"
#include "AsMetaType.h"
#include "AsGlobalData.h"

// 内置配置属性
class ADF_EXPORT AsInnerConfigData : public AsJsonObject 
{
public:
	bool	isDebugMode;		//调试模式
	QString dataDir;			//原数据路径
	QString resultDir;			//结果数据路径

public:
	virtual void onBuildStructure()const override {
		DECLARE_JSON_VAR(isDebugMode);
		DECLARE_JSON_VAR(dataDir);
		DECLARE_JSON_VAR(resultDir);
	}
};

AS_DECLARE_META_TYPE(AsInnerConfigData)

class ADF_EXPORT AsConfig : public AsGlobalData {
public:
	AsConfig();
	virtual ~AsConfig();

private:
	static QSet<QString> ms_setConfigType;
	static QString m_qsFilePath;							//配置文件路径

private:
	QMap<QString, AsJsonObject*>			m_mpObject;
	bool									m_isAutoSave;	//是否自动保存，默认为否

private:
	void init();

public:
	static void setFilePath(QString filePath);
	// 保存配置文件
	inline void setAutoSave(bool bAutoSave) { m_isAutoSave=bAutoSave;}
	void save();
	void load();

public:
	// 获取配置数据
	template<typename T>
	T* getConfigData() {
		QString qsTypeName = asMetaType<T>();
		if (m_mpObject.contains(qsTypeName)) {
			return (T*)m_mpObject.value(qsTypeName);
		}
		else {}
		return nullptr;
	}
	// 注册配置类型
	template<typename T>
	static void registerType() {
		asRegisterMetaType<T>();
		ms_setConfigType << asMetaType<T>();
	}

};

AS_DECLARE_META_TYPE(AsConfig)

namespace As {
	/**
	 * @desc 注册配置类元类型
	 * @param
	 *	-T:配置类型模板
	 */
	template<typename T>
	void registerConfigMetaType() {
		AsConfig::registerType<T>();
	}

};