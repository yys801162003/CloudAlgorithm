﻿#include "AsTask.h"
#include "AsCommunicator.h"

class ADF_EXPORT AsCommuniWaitTask : public AsTask {
	Q_OBJECT

public:
	AsCommuniWaitTask(AsCommunicator* pCommunicator, int waitCommand, int timeout = -1);

private:
	AsCommunicator* m_pCommunicator;				//检测算子
	int				m_iWaitCommand;
	int				m_iWaitTimeout;
	bool			m_bGotSignal;

public:
	virtual int onTaskAction() override;			//执行任务

public slots:
	void onReceiveCommand(int cmd);

};
