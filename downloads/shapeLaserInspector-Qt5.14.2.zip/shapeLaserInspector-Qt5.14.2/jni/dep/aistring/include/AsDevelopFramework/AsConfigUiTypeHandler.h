﻿#pragma once
#include "ADFGlobal.h"
#include <QComboBox>

class ADF_EXPORT AsConfigUiTypeHandler
{
public:
	virtual ~AsConfigUiTypeHandler() {}

	virtual void uiToData(QWidget* pControl,void* data) = 0;			//界面转数据

	virtual void dataToUi(void* data,QWidget* pControl) = 0;			//数据转界面

	virtual QString uiPrefix() = 0;											//ui前缀

	virtual QWidget* createUi() { return nullptr;}						//创建Ui，绑定已有界面时可以不实现
};

