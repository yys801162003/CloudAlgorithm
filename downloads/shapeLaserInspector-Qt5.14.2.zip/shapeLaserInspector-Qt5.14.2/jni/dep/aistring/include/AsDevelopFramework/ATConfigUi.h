﻿#pragma once
#include "ADFGlobal.h"
#include "AsJsonObject.h"

/**
 * 测试平台界面包装器基类
 */
class ADF_EXPORT ATConfigUi {
public:
	virtual int execParamDialog(AsJsonObject* pParam) = 0;

private:

};
