﻿#pragma once

#ifndef BUILD_STATIC
# if defined(ASDEVELOPFRAMEWORK_LIB)
#  define ADF_EXPORT __declspec(dllexport)
# else
#  define ADF_EXPORT __declspec(dllimport)
# endif
#else
# define ADF_EXPORT
#endif

#include <QtCore/qglobal.h>
#include <QDebug>
#include "AsDefine.h"