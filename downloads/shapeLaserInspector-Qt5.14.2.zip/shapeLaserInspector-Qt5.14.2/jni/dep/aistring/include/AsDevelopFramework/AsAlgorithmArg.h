﻿#pragma once
#include "ADFGlobal.h"
#include "AsPluginArgsBase.h"

class AsAlgorithmInputArg : public AsPluginArgsBase {
public:
	cv::Mat mat;
	std::vector<QVariant> params;

};

class AsAlgorithmOutputArg :public AsPluginArgsBase {
public:
	cv::Mat mat;

};

namespace As {

	ADF_EXPORT void parseInputArgs(const AsPluginArgsAll& argsAll, cv::Mat& mat, std::vector<QVariant>& params);

	ADF_EXPORT void writeOutputMat(const cv::Mat& mat, const AsPluginArgsAll& argsAll);
};


