﻿#pragma once
#include "ADFGlobal.h"
#include "AsPlugin.h"
#include "AsPluginFnRegister.h"
#include "AsPluginArgsBase.h"
#include "AsParamReader.h"
#include <QMap>
#include <functional>

/**
 * @desc 分析函数注册，需在AsAnalysePlugin子类中使用
 */
#define REGISTER_ANALYSE_FUN(TYPE,FUNC) registerFn(#FUNC, std::bind(&TYPE::FUNC, \
AsGlobalInstance<TYPE>::getInstance(), std::placeholders::_1, std::placeholders::_2, std::placeholders::_3))

 // 重定义分析函数
typedef std::function<int(cv::Mat&, cv::Mat&, AsParamReader&)> AnaFunction;

// 输出参数
class AsAnalyseOutputArg : public AsPluginArgsBase {
public:
	QMap<QString, AnaFunction> fnMap;		//算法函数

};

// 分析插件
class ADF_EXPORT AsAnalysePlugin : public AsPlugin {
public:
	virtual ~AsAnalysePlugin();

protected:
	QMap<QString, AnaFunction> m_fnMap;		//算法函数

public:
	static void resolveEntries(AsPlugin* pPlugin);

public:
	virtual void afterCall() override;
	virtual void resolveEntriesFn() = 0;

};

// 分析动态库插件注册器
class ADF_EXPORT AsAnalysePluginRegister : public AsPluginFnRegister {
private:
	std::string m_libName;

public:
	AsAnalysePluginRegister(const std::string& libName);

protected:
	virtual void onInit() override;

};

